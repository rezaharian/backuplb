<?php

namespace App\Http\Controllers;

use App\Models\jalur;
use Illuminate\Http\Request;

class JalurController extends Controller
{
    public function index()
    {
        return back();
    }

   
}


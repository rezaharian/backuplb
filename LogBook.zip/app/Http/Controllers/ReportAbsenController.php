<?php

namespace App\Http\Controllers;

use App\Models\absen_d;
use App\Models\absen_h;
use App\Models\onoff_tg;
use App\Models\overtime;
use App\Models\pegawai;
use App\Models\Presensi;
use App\Models\Tdkabsen;
use App\Models\TglLibur;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

use PhpOffice\PhpSpreadsheet\Calculation\Statistical\Maximum;

class ReportAbsenController extends Controller
{
    //

    public function index()
    {
        return view('../hr/dashboard/reportabsen/index');
    }

    public function list(Request $request)
    {
        set_time_limit(500);
        $tgl_awal = Carbon::parse($request->tgl_awal);
        $tgl_akhir = Carbon::parse($request->tgl_akhir);

        $taw = Carbon::parse($request->tgl_awal)->format('d-m-Y');
        $tak = Carbon::parse($request->tgl_akhir)->format('d-m-Y');

        $daftar_tanggal = [];
        $jumlah_hari = $tgl_akhir->diffInDays($tgl_awal);

        for ($i = 0; $i <= $jumlah_hari; $i++) {
            $daftar_tanggal[] = $tgl_awal
                ->copy()
                ->addDays($i)
                ->format('Y-m-d');
        }

        $nik = $request->no_payroll;

        $pegawaiQuery = Pegawai::where(function ($query) {
            $query->whereNull('tgl_keluar')
                  ->orWhere('tgl_keluar', '');
        })
        ->where('bagian', '!=', 'DIREKSI')
        ->orderBy('no_payroll', 'asc');
        
        if ($nik) {
            $pegawaiQuery->where('no_payroll', $nik);
        }

        $pegawai = $pegawaiQuery->get(); // Mengambil daftar pegawai

        $pegawaiData = [];

        // Mengumpulkan semua nomor registrasi pegawai
        $noRegistrasiPegawai = $pegawai->pluck('no_payroll')->toArray();

        // Mengambil data absen pegawai
        $absen = Presensi::whereIn('no_reg', $noRegistrasiPegawai)
            ->whereIn('tanggal', $daftar_tanggal)
            ->orderBy('tanggal', 'asc')
            ->get();

        // Mengumpulkan semua tanggal absen
        $absen_tanggal = $absen->pluck('tanggal')->toArray();

        // Mengumpulkan data onoff_tg berdasarkan tanggal
        $onoff_tg = onoff_tg::whereIn('tgl_off', $absen_tanggal)
            ->orWhereIn('tgl_on', $absen_tanggal)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model pertama tanpa absen_h
        $absen_d = absen_d::whereIn('tgl_absen', $absen_tanggal)
            ->whereIn('no_reg', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model kedua dengan absen_h
        // $absen_d = absen_d::join('absen_hs', 'absen_ds.int_absen', '=', 'absen_hs.int_absen')
        // ->whereIn('absen_ds.tgl_absen', $absen_tanggal)
        // ->get();

        // Mengumpulkan data tdkabsen berdasarkan nomor registrasi pegawai dan tanggal absen
        $tdkabsen = Tdkabsen::whereIn('no_payroll', $noRegistrasiPegawai)
            ->whereIn('ta_tgl', $absen_tanggal)
            ->get();

        // Mengumpulkan data lembur berdasarkan tanggal dan nomor registrasi pegawai
        $lembur = overtime::whereIn('ot_dat', $absen_tanggal)
            ->whereIn('no_payroll', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data tgl_libur berdasarkan tanggal
        $tglLibur = TglLibur::whereIn('tgl_libur', $absen_tanggal)
            ->pluck('tgl_libur')
            ->toArray();

        $pegawaiData = [];
        $shift3_total = 0;
        $shift2_total = 0;
        $uml2_total = 0;
        $uml1_total = 0;
        foreach ($pegawai as $peg) {
            $pegawaiAbsen = $absen->where('no_reg', $peg->no_payroll);

            // Tambahkan tanggal yang tidak ada dalam database ke dalam koleksi absen
            $missing_tanggal = array_diff($daftar_tanggal, $pegawaiAbsen->pluck('tanggal')->toArray());

            foreach ($missing_tanggal as $tanggal) {
                $tanggalObj = Carbon::parse($tanggal);

                $newAbsen = [
                    'tanggal' => $tanggalObj,
                    'masuk' => '',
                    'keluar' => '',
                    'lembur' => '',
                    'ket' => $tanggalObj->isSaturday() ? 'Sabtu' : ($tanggalObj->isSunday() ? 'Minggu' : ''),
                ];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $newAbsen['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $newAbsen['ket'] = 'on';
                    }
                }

                if (in_array($tanggal, $tglLibur)) {
                    $newAbsen['ket'] = 'LN';
                } else {
                    $newAbsen['ket'] = $newAbsen['ket'] ?: '';
                }

                $pegawaiAbsen->push($newAbsen);
            }

            // Urutkan kembali koleksi absen berdasarkan tanggal
            $pegawaiAbsen = $pegawaiAbsen->sortBy('tanggal');

            $jumlah_hari = 0;
            $uml1 = 0; // Jumlah hari biasa atau hari libur dengan kondisi on
            $uml2 = 0; // Jumlah hari biasa atau hari libur dengan kondisi off
            $shift2 = 0;
            $shift3 = 0;
            $total_lembur = 0; // Inisialisasi variabel total_lembur di awal

            foreach ($pegawaiAbsen as &$item) {
                $tanggal = $item['tanggal'];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $item['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $item['ket'] = 'on';
                    }
                } else {
                    if (in_array($tanggal, $tglLibur)) {
                        $item['ket'] = 'LN';
                    } else {
                        $item['ket'] = $item['ket'] ?: '';
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $jumlah_hari++;
                }

                $absenData = $absen_d
                    ->where('tgl_absen', $tanggal)
                    ->where('no_reg', $peg->no_payroll)
                    ->first();

                if ($absenData) {
                    $item['ket'] = $absenData->jns_absen;
                }

                $masuk = Carbon::parse($item['masuk']);
                $keluar = Carbon::parse($item['keluar']);

                $lemburData = $lembur
                    ->where('ot_dat', $tanggal)
                    ->where('no_payroll', $peg->no_payroll)
                    ->first();

                // Menghitung lembur
                if ($lemburData) {
                    $start = Carbon::parse($lemburData->ot_hrb);
                    $end = Carbon::parse($lemburData->ot_hre);

                    $start_convert = $start->hour * 60 + $start->minute; // Konversi ke menit
                    $end_convert = $end->hour * 60 + $end->minute; // Konversi ke menit
                    $masuk_convert = $masuk->hour * 60 + $masuk->minute; // Konversi ke menit
                    $keluar_convert = $keluar->hour * 60 + $keluar->minute; // Konversi ke menit

                    if ($start_convert >= $end_convert) {
                        $end_convert = $end_convert + 1440;
                    } else {
                        $menit_lembur = $end_convert - $start_convert;
                    }
                    if ($masuk_convert >= $keluar_convert) {
                        $keluar_convert = $keluar_convert + 1440;
                    }

                    // periksa jam masuk dan jam mulai lembur
                    if ($masuk_convert >= $start_convert) {
                        $start = $masuk_convert; // Mulai hitung lembur dari waktu masuk
                    } else {
                        $start = $start_convert;
                    }

                    // Periksa apakah lembur berakhir setelah waktu keluar
                    if ($end_convert >= $keluar_convert) {
                        $end = $keluar_convert; // Akhiri hitungan lembur pada waktu keluar
                    } else {
                        $end = $end_convert;
                    }

                    $lembur_a = $end - $start;
                    $lemburHours = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value
                    $lembur_hours_asli = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value

                    if ($lemburHours > 5) {
                        $lemburHours -= 0.5;
                    }
                    $lembur_asli = $lembur_hours_asli;

                    // Menghitung lembur berdasarkan kondisi
                    if ($item['ket'] == 'on' && (date('N', strtotime($tanggalObj)) == 6 || date('N', strtotime($tanggalObj)) == 7)) {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    } elseif ($item['ket'] == 'LN' || $item['ket'] == 'off') {
                        $lemburHours *= 2;
                    } else {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    }

                    $item['lembur'] = $lembur_asli;
                    $item['total_lembur'] = $lemburHours; // Menyimpan total lembur pada item absen
                    $total_lembur += $lemburHours;
                }

                $tgl = Carbon::parse($tanggal);

                // Hitung jumlah hari kerja (tidak termasuk hari libur)
                if ((!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E'])) || $item['ket'] == 'on') {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if ($masuk_time->hour < 12 && $keluar_time->between(Carbon::parse('17:45'), Carbon::parse('18:30'))) {
                        // Periksa apakah hari ini bukan Sabtu atau Minggu
                        if (!$tgl->isWeekend()) {
                            $uml1++;
                            $uml1_total++;
                        }
                    }
                }

                // Hitung jumlah hari uml2
                if (!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E']) && (in_array($tgl->dayOfWeek, [0, 6]) || $item['ket'] == 'LN' || $tgl->isWeekend() || $item['ket'] == 'off') && $lemburHours < 6) {
                    $uml2++;
                    $uml2_total++;
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('18:00', '23:59') && $keluar_time->isBetween('05:00', '11:00')) || ($masuk_time->isBetween('13:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift3++;
                        $shift3_total++;
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('06:00', '17:00') && $keluar_time->isBetween('21:00', '23:59')) || ($masuk_time->isBetween('12:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift2++;
                        $shift2_total++;
                    }
                }
            }

            $daftar_tanggal_absen = $pegawaiAbsen->pluck('tanggal')->toArray();

            foreach ($tdkabsen as $tdk) {
                $tanggal = $tdk->ta_tgl;
                $status = $tdk->status;

                foreach ($pegawaiAbsen as &$item) {
                    $itemTanggal = Carbon::parse($item['tanggal']);

                    if ($itemTanggal->format('Y-m-d') === $tanggal) {
                        $item['ket'] = $status;
                        break;
                    }
                }
            }

            $pegawaiData[] = [
                'pegawai' => $peg,
                'absen' => $pegawaiAbsen,
                'jumlah_hari' => $jumlah_hari,
                'total_lembur' => $total_lembur,
                'uml1' => $uml1,
                'uml2' => $uml2,
                'shift2' => $shift2,
                'shift3' => $shift3,
            ];
        }

        return view('../hr/dashboard/reportabsen/list', [
            'shift3_total' => $shift3_total,
            'shift2_total' => $shift2_total,
            'uml2_total' => $uml2_total,
            'uml1_total' => $uml1_total,
            'pegawaiData' => $pegawaiData,
            'tgl_awal' => $taw,
            'tgl_akhir' => $tak,
        ]);
    }

    public function list_print(Request $request)
    {
        set_time_limit(500);
        $tgl_awal = Carbon::parse($request->tgl_awal);
        $tgl_akhir = Carbon::parse($request->tgl_akhir);

        $taw = Carbon::parse($request->tgl_awal)->format('d-m-Y');
        $tak = Carbon::parse($request->tgl_akhir)->format('d-m-Y');

        $daftar_tanggal = [];
        $jumlah_hari = $tgl_akhir->diffInDays($tgl_awal);

        for ($i = 0; $i <= $jumlah_hari; $i++) {
            $daftar_tanggal[] = $tgl_awal
                ->copy()
                ->addDays($i)
                ->format('Y-m-d');
        }

        $nik = $request->no_payroll;

        $pegawaiQuery = Pegawai::where(function ($query) {
            $query->whereNull('tgl_keluar')
                  ->orWhere('tgl_keluar', '');
        })
        ->where('bagian', '!=', 'DIREKSI')
        ->orderBy('no_payroll', 'asc');
        
        if ($nik) {
            $pegawaiQuery->where('no_payroll', $nik);
        }

        $pegawai = $pegawaiQuery->get(); // Mengambil daftar pegawai

        $pegawaiData = [];

        // Mengumpulkan semua nomor registrasi pegawai
        $noRegistrasiPegawai = $pegawai->pluck('no_payroll')->toArray();

        // Mengambil data absen pegawai
        $absen = Presensi::whereIn('no_reg', $noRegistrasiPegawai)
            ->whereIn('tanggal', $daftar_tanggal)
            ->orderBy('tanggal', 'asc')
            ->get();

        // Mengumpulkan semua tanggal absen
        $absen_tanggal = $absen->pluck('tanggal')->toArray();

        // Mengumpulkan data onoff_tg berdasarkan tanggal
        $onoff_tg = onoff_tg::whereIn('tgl_off', $absen_tanggal)
            ->orWhereIn('tgl_on', $absen_tanggal)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model pertama tanpa absen_h
        $absen_d = absen_d::whereIn('tgl_absen', $absen_tanggal)
            ->whereIn('no_reg', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model kedua dengan absen_h
        // $absen_d = absen_d::join('absen_hs', 'absen_ds.int_absen', '=', 'absen_hs.int_absen')
        // ->whereIn('absen_ds.tgl_absen', $absen_tanggal)
        // ->get();

        // Mengumpulkan data tdkabsen berdasarkan nomor registrasi pegawai dan tanggal absen
        $tdkabsen = Tdkabsen::whereIn('no_payroll', $noRegistrasiPegawai)
            ->whereIn('ta_tgl', $absen_tanggal)
            ->get();

        // Mengumpulkan data lembur berdasarkan tanggal dan nomor registrasi pegawai
        $lembur = overtime::whereIn('ot_dat', $absen_tanggal)
            ->whereIn('no_payroll', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data tgl_libur berdasarkan tanggal
        $tglLibur = TglLibur::whereIn('tgl_libur', $absen_tanggal)
            ->pluck('tgl_libur')
            ->toArray();

        $pegawaiData = [];
        $shift3_total = 0;
        $shift2_total = 0;
        $uml2_total = 0;
        $uml1_total = 0;
        foreach ($pegawai as $peg) {
            $pegawaiAbsen = $absen->where('no_reg', $peg->no_payroll);

            // Tambahkan tanggal yang tidak ada dalam database ke dalam koleksi absen
            $missing_tanggal = array_diff($daftar_tanggal, $pegawaiAbsen->pluck('tanggal')->toArray());

            foreach ($missing_tanggal as $tanggal) {
                $tanggalObj = Carbon::parse($tanggal);

                $newAbsen = [
                    'tanggal' => $tanggalObj,
                    'masuk' => '',
                    'keluar' => '',
                    'lembur' => '',
                    'ket' => $tanggalObj->isSaturday() ? 'Sabtu' : ($tanggalObj->isSunday() ? 'Minggu' : ''),
                ];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $newAbsen['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $newAbsen['ket'] = 'on';
                    }
                }

                if (in_array($tanggal, $tglLibur)) {
                    $newAbsen['ket'] = 'LN';
                } else {
                    $newAbsen['ket'] = $newAbsen['ket'] ?: '';
                }

                $pegawaiAbsen->push($newAbsen);
            }

            // Urutkan kembali koleksi absen berdasarkan tanggal
            $pegawaiAbsen = $pegawaiAbsen->sortBy('tanggal');

            $jumlah_hari = 0;
            $uml1 = 0; // Jumlah hari biasa atau hari libur dengan kondisi on
            $uml2 = 0; // Jumlah hari biasa atau hari libur dengan kondisi off
            $shift2 = 0;
            $shift3 = 0;
            $total_lembur = 0; // Inisialisasi variabel total_lembur di awal

            foreach ($pegawaiAbsen as &$item) {
                $tanggal = $item['tanggal'];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $item['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $item['ket'] = 'on';
                    }
                } else {
                    if (in_array($tanggal, $tglLibur)) {
                        $item['ket'] = 'LN';
                    } else {
                        $item['ket'] = $item['ket'] ?: '';
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $jumlah_hari++;
                }

                $absenData = $absen_d
                    ->where('tgl_absen', $tanggal)
                    ->where('no_reg', $peg->no_payroll)
                    ->first();

                if ($absenData) {
                    $item['ket'] = $absenData->jns_absen;
                }

                $masuk = Carbon::parse($item['masuk']);
                $keluar = Carbon::parse($item['keluar']);

                $lemburData = $lembur
                    ->where('ot_dat', $tanggal)
                    ->where('no_payroll', $peg->no_payroll)
                    ->first();

                // Menghitung lembur
                if ($lemburData) {
                    $start = Carbon::parse($lemburData->ot_hrb);
                    $end = Carbon::parse($lemburData->ot_hre);

                    $start_convert = $start->hour * 60 + $start->minute; // Konversi ke menit
                    $end_convert = $end->hour * 60 + $end->minute; // Konversi ke menit
                    $masuk_convert = $masuk->hour * 60 + $masuk->minute; // Konversi ke menit
                    $keluar_convert = $keluar->hour * 60 + $keluar->minute; // Konversi ke menit

                    if ($start_convert >= $end_convert) {
                        $end_convert = $end_convert + 1440;
                    } else {
                        $menit_lembur = $end_convert - $start_convert;
                    }
                    if ($masuk_convert >= $keluar_convert) {
                        $keluar_convert = $keluar_convert + 1440;
                    }

                    // periksa jam masuk dan jam mulai lembur
                    if ($masuk_convert >= $start_convert) {
                        $start = $masuk_convert; // Mulai hitung lembur dari waktu masuk
                    } else {
                        $start = $start_convert;
                    }

                    // Periksa apakah lembur berakhir setelah waktu keluar
                    if ($end_convert >= $keluar_convert) {
                        $end = $keluar_convert; // Akhiri hitungan lembur pada waktu keluar
                    } else {
                        $end = $end_convert;
                    }

                    $lembur_a = $end - $start;
                    $lemburHours = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value
                    $lembur_hours_asli = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value

                    if ($lemburHours > 5) {
                        $lemburHours -= 0.5;
                    }
                    $lembur_asli = $lembur_hours_asli;

                    // Menghitung lembur berdasarkan kondisi
                    if ($item['ket'] == 'on' && (date('N', strtotime($tanggalObj)) == 6 || date('N', strtotime($tanggalObj)) == 7)) {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    } elseif ($item['ket'] == 'LN' || $item['ket'] == 'off') {
                        $lemburHours *= 2;
                    } else {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    }

                    $item['lembur'] = $lembur_asli;
                    $item['total_lembur'] = $lemburHours; // Menyimpan total lembur pada item absen
                    $total_lembur += $lemburHours;
                }

                $tgl = Carbon::parse($tanggal);

                // Hitung jumlah hari kerja (tidak termasuk hari libur)
                if ((!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E'])) || $item['ket'] == 'on') {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if ($masuk_time->hour < 12 && $keluar_time->between(Carbon::parse('17:45'), Carbon::parse('18:30'))) {
                        // Periksa apakah hari ini bukan Sabtu atau Minggu
                        if (!$tgl->isWeekend()) {
                            $uml1++;
                            $uml1_total++;
                        }
                    }
                }

                // Hitung jumlah hari uml2
                if (!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E']) && (in_array($tgl->dayOfWeek, [0, 6]) || $item['ket'] == 'LN' || $tgl->isWeekend() || $item['ket'] == 'off') && $lemburHours < 6) {
                    $uml2++;
                    $uml2_total++;
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('18:00', '23:59') && $keluar_time->isBetween('05:00', '11:00')) || ($masuk_time->isBetween('13:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift3++;
                        $shift3_total++;
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('06:00', '17:00') && $keluar_time->isBetween('21:00', '23:59')) || ($masuk_time->isBetween('12:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift2++;
                        $shift2_total++;
                    }
                }
            }

            $daftar_tanggal_absen = $pegawaiAbsen->pluck('tanggal')->toArray();

            foreach ($tdkabsen as $tdk) {
                $tanggal = $tdk->ta_tgl;
                $status = $tdk->status;

                foreach ($pegawaiAbsen as &$item) {
                    $itemTanggal = Carbon::parse($item['tanggal']);

                    if ($itemTanggal->format('Y-m-d') === $tanggal) {
                        $item['ket'] = $status;
                        break;
                    }
                }
            }

            $pegawaiData[] = [
                'pegawai' => $peg,
                'absen' => $pegawaiAbsen,
                'jumlah_hari' => $jumlah_hari,
                'total_lembur' => $total_lembur,
                'uml1' => $uml1,
                'uml2' => $uml2,
                'shift2' => $shift2,
                'shift3' => $shift3,
            ];
        
        }
        $pdf = Pdf::loadview('/hr/dashboard/reportabsen/list_print', ['shift3' => $shift3, 'shift2' => $shift2, 'uml2' => $uml2, 'uml1' => $uml1, 'pegawaiData' => $pegawaiData, 'tgl_awal' => $taw, 'tgl_akhir' => $tak, 'total_lembur' => $total_lembur]);
        return $pdf->setPaper('a4', 'potrait')->stream('uraianlembur.pdf');
    }
    // jhvbnmjhvbnjhbvbn
    public function uraianlembur(Request $request)
    {
        set_time_limit(500);
        $tgl_awal = Carbon::parse($request->tgl_awal);
        $tgl_akhir = Carbon::parse($request->tgl_akhir);

        $taw = Carbon::parse($request->tgl_awal)->format('d-m-Y');
        $tak = Carbon::parse($request->tgl_akhir)->format('d-m-Y');

        $daftar_tanggal = [];
        $jumlah_hari = $tgl_akhir->diffInDays($tgl_awal);

        for ($i = 0; $i <= $jumlah_hari; $i++) {
            $daftar_tanggal[] = $tgl_awal
                ->copy()
                ->addDays($i)
                ->format('Y-m-d');
        }

        $nik = $request->no_payroll;

        $pegawaiQuery = Pegawai::where(function ($query) {
            $query->whereNull('tgl_keluar')
                  ->orWhere('tgl_keluar', '');
        })
        ->where('bagian', '!=', 'DIREKSI')
        ->orderBy('no_payroll', 'asc');
        
        if ($nik) {
            $pegawaiQuery->where('no_payroll', $nik);
        }

        $pegawai = $pegawaiQuery->get(); // Mengambil daftar pegawai

        $pegawaiData = [];

        // Mengumpulkan semua nomor registrasi pegawai
        $noRegistrasiPegawai = $pegawai->pluck('no_payroll')->toArray();

        // Mengambil data absen pegawai
        $absen = Presensi::whereIn('no_reg', $noRegistrasiPegawai)
            ->whereIn('tanggal', $daftar_tanggal)
            ->orderBy('tanggal', 'asc')
            ->get();

        // Mengumpulkan semua tanggal absen
        $absen_tanggal = $absen->pluck('tanggal')->toArray();

        // Mengumpulkan data onoff_tg berdasarkan tanggal
        $onoff_tg = onoff_tg::whereIn('tgl_off', $absen_tanggal)
            ->orWhereIn('tgl_on', $absen_tanggal)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model pertama tanpa absen_h
        $absen_d = absen_d::whereIn('tgl_absen', $absen_tanggal)
            ->whereIn('no_reg', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model kedua dengan absen_h
        // $absen_d = absen_d::join('absen_hs', 'absen_ds.int_absen', '=', 'absen_hs.int_absen')
        // ->whereIn('absen_ds.tgl_absen', $absen_tanggal)
        // ->get();

        // Mengumpulkan data tdkabsen berdasarkan nomor registrasi pegawai dan tanggal absen
        $tdkabsen = Tdkabsen::whereIn('no_payroll', $noRegistrasiPegawai)
            ->whereIn('ta_tgl', $absen_tanggal)
            ->get();

        // Mengumpulkan data lembur berdasarkan tanggal dan nomor registrasi pegawai
        $lembur = overtime::whereIn('ot_dat', $absen_tanggal)
            ->whereIn('no_payroll', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data tgl_libur berdasarkan tanggal
        $tglLibur = TglLibur::whereIn('tgl_libur', $absen_tanggal)
            ->pluck('tgl_libur')
            ->toArray();

        $pegawaiData = [];
        $shift3_total = 0;
        $shift2_total = 0;
        $uml2_total = 0;
        $uml1_total = 0;
        foreach ($pegawai as $peg) {
            $pegawaiAbsen = $absen->where('no_reg', $peg->no_payroll);

            // Tambahkan tanggal yang tidak ada dalam database ke dalam koleksi absen
            $missing_tanggal = array_diff($daftar_tanggal, $pegawaiAbsen->pluck('tanggal')->toArray());

            foreach ($missing_tanggal as $tanggal) {
                $tanggalObj = Carbon::parse($tanggal);

                $newAbsen = [
                    'tanggal' => $tanggalObj,
                    'masuk' => '',
                    'keluar' => '',
                    'lembur' => '',
                    'ket' => $tanggalObj->isSaturday() ? 'Sabtu' : ($tanggalObj->isSunday() ? 'Minggu' : ''),
                ];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $newAbsen['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $newAbsen['ket'] = 'on';
                    }
                }

                if (in_array($tanggal, $tglLibur)) {
                    $newAbsen['ket'] = 'LN';
                } else {
                    $newAbsen['ket'] = $newAbsen['ket'] ?: '';
                }

                $pegawaiAbsen->push($newAbsen);
            }

            // Urutkan kembali koleksi absen berdasarkan tanggal
            $pegawaiAbsen = $pegawaiAbsen->sortBy('tanggal');

            $jumlah_hari = 0;
            $uml1 = 0; // Jumlah hari biasa atau hari libur dengan kondisi on
            $uml2 = 0; // Jumlah hari biasa atau hari libur dengan kondisi off
            $shift2 = 0;
            $shift3 = 0;
            $total_lembur = 0; // Inisialisasi variabel total_lembur di awal

            foreach ($pegawaiAbsen as &$item) {
                $tanggal = $item['tanggal'];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $item['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $item['ket'] = 'on';
                    }
                } else {
                    if (in_array($tanggal, $tglLibur)) {
                        $item['ket'] = 'LN';
                    } else {
                        $item['ket'] = $item['ket'] ?: '';
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $jumlah_hari++;
                }

                $absenData = $absen_d
                    ->where('tgl_absen', $tanggal)
                    ->where('no_reg', $peg->no_payroll)
                    ->first();

                if ($absenData) {
                    $item['ket'] = $absenData->jns_absen;
                }

                $masuk = Carbon::parse($item['masuk']);
                $keluar = Carbon::parse($item['keluar']);

                $lemburData = $lembur
                    ->where('ot_dat', $tanggal)
                    ->where('no_payroll', $peg->no_payroll)
                    ->first();

                // Menghitung lembur
                if ($lemburData) {
                    $start = Carbon::parse($lemburData->ot_hrb);
                    $end = Carbon::parse($lemburData->ot_hre);

                    $startq = Carbon::parse($lemburData->ot_hrb)->format('H:i');
                    $endq = Carbon::parse($lemburData->ot_hre)->format('H:i');

                    $item['start'] = $startq;
                    $item['end'] = $endq;

                    $start_convert = $start->hour * 60 + $start->minute; // Konversi ke menit
                    $end_convert = $end->hour * 60 + $end->minute; // Konversi ke menit
                    $masuk_convert = $masuk->hour * 60 + $masuk->minute; // Konversi ke menit
                    $keluar_convert = $keluar->hour * 60 + $keluar->minute; // Konversi ke menit

                    if ($start_convert >= $end_convert) {
                        $end_convert = $end_convert + 1440;
                    } else {
                        $menit_lembur = $end_convert - $start_convert;
                    }
                    if ($masuk_convert >= $keluar_convert) {
                        $keluar_convert = $keluar_convert + 1440;
                    }

                    // periksa jam masuk dan jam mulai lembur
                    if ($masuk_convert >= $start_convert) {
                        $start = $masuk_convert; // Mulai hitung lembur dari waktu masuk
                    } else {
                        $start = $start_convert;
                    }

                    // Periksa apakah lembur berakhir setelah waktu keluar
                    if ($end_convert >= $keluar_convert) {
                        $end = $keluar_convert; // Akhiri hitungan lembur pada waktu keluar
                    } else {
                        $end = $end_convert;
                    }

                    $lembur_a = $end - $start;
                    $lemburHours = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value
                    $lembur_hours_asli = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value

                    if ($lemburHours > 5) {
                        $lemburHours -= 0.5;
                    }
                    $lembur_asli = $lembur_hours_asli;

                    // Menghitung lembur berdasarkan kondisi
                    if ($item['ket'] == 'on' && (date('N', strtotime($tanggalObj)) == 6 || date('N', strtotime($tanggalObj)) == 7)) {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    } elseif ($item['ket'] == 'LN' || $item['ket'] == 'off') {
                        $lemburHours *= 2;
                    } else {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    }


                    $item['lembur'] = $lembur_hours_asli;
                    $item['lembur_total'] = $lemburHours;
                    $total_lembur += $lemburHours;
                }

                $tgl = Carbon::parse($tanggal);

                // Hitung jumlah hari kerja (tidak termasuk hari libur)
                if ((!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E'])) || $item['ket'] == 'on') {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if ($masuk_time->hour < 12 && $keluar_time->between(Carbon::parse('17:45'), Carbon::parse('18:30'))) {
                        // Periksa apakah hari ini bukan Sabtu atau Minggu
                        if (!$tgl->isWeekend()) {
                            $uml1++;
                            $uml1_total++;
                        }
                    }
                }

                // Hitung jumlah hari uml2
                if (!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E']) && (in_array($tgl->dayOfWeek, [0, 6]) || $item['ket'] == 'LN' || $tgl->isWeekend() || $item['ket'] == 'off') && $lemburHours < 6) {
                    $uml2++;
                    $uml2_total++;
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('18:00', '23:59') && $keluar_time->isBetween('05:00', '11:00')) || ($masuk_time->isBetween('13:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift3++;
                        $shift3_total++;
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('06:00', '17:00') && $keluar_time->isBetween('21:00', '23:59')) || ($masuk_time->isBetween('12:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift2++;
                        $shift2_total++;
                    }
                }
            }

            $daftar_tanggal_absen = $pegawaiAbsen->pluck('tanggal')->toArray();

            foreach ($tdkabsen as $tdk) {
                $tanggal = $tdk->ta_tgl;
                $status = $tdk->status;

                foreach ($pegawaiAbsen as &$item) {
                    $itemTanggal = Carbon::parse($item['tanggal']);

                    if ($itemTanggal->format('Y-m-d') === $tanggal) {
                        $item['ket'] = $status;
                        break;
                    }
                }
            }

            $pegawaiData[] = [
                'pegawai' => $peg,
                'absen' => $pegawaiAbsen,
                'jumlah_hari' => $jumlah_hari,
                'total_lembur' => $total_lembur,
                'uml1' => $uml1,
                'uml2' => $uml2,
                'shift2' => $shift2,
                'shift3' => $shift3,
            ];
        
        
        }

        return view('../hr/dashboard/reportabsen/uraianlembur', ['pegawaiData' => $pegawaiData, 'tgl_awal' => $taw, 'tgl_akhir' => $tak, 'total_lembur' => $total_lembur]);
    }

    // kjhcvbjhuyguhbjiugyhb
    public function rekapgaji(Request $request)
    {
        set_time_limit(500);
        $tgl_awal = Carbon::parse($request->tgl_awal);
        $tgl_akhir = Carbon::parse($request->tgl_akhir);

        $taw = Carbon::parse($request->tgl_awal)->format('d-m-Y');
        $tak = Carbon::parse($request->tgl_akhir)->format('d-m-Y');

        $daftar_tanggal = [];
        $jumlah_hari = $tgl_akhir->diffInDays($tgl_awal);

        for ($i = 0; $i <= $jumlah_hari; $i++) {
            $daftar_tanggal[] = $tgl_awal
                ->copy()
                ->addDays($i)
                ->format('Y-m-d');
        }

        $nik = $request->no_payroll;

        $pegawaiQuery = Pegawai::where(function ($query) {
            $query->whereNull('tgl_keluar')
                  ->orWhere('tgl_keluar', '');
        })
        ->where('bagian', '!=', 'DIREKSI')
        ->orderBy('no_payroll', 'asc');
        
        if ($nik) {
            $pegawaiQuery->where('no_payroll', $nik);
        }

        $pegawai = $pegawaiQuery->get(); // Mengambil daftar pegawai

        $pegawaiData = [];

        // Mengumpulkan semua nomor registrasi pegawai
        $noRegistrasiPegawai = $pegawai->pluck('no_payroll')->toArray();

        // Mengambil data absen pegawai
        $absen = Presensi::whereIn('no_reg', $noRegistrasiPegawai)
            ->whereIn('tanggal', $daftar_tanggal)
            ->orderBy('tanggal', 'asc')
            ->get();

        // Mengumpulkan semua tanggal absen
        $absen_tanggal = $absen->pluck('tanggal')->toArray();

        // Mengumpulkan data onoff_tg berdasarkan tanggal
        $onoff_tg = onoff_tg::whereIn('tgl_off', $absen_tanggal)
            ->orWhereIn('tgl_on', $absen_tanggal)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model pertama tanpa absen_h
        $absen_d = absen_d::whereIn('tgl_absen', $absen_tanggal)
            ->whereIn('no_reg', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model kedua dengan absen_h
        // $absen_d = absen_d::join('absen_hs', 'absen_ds.int_absen', '=', 'absen_hs.int_absen')
        // ->whereIn('absen_ds.tgl_absen', $absen_tanggal)
        // ->get();

        // Mengumpulkan data tdkabsen berdasarkan nomor registrasi pegawai dan tanggal absen
        $tdkabsen = Tdkabsen::whereIn('no_payroll', $noRegistrasiPegawai)
            ->whereIn('ta_tgl', $absen_tanggal)
            ->get();

        // Mengumpulkan data lembur berdasarkan tanggal dan nomor registrasi pegawai
        $lembur = overtime::whereIn('ot_dat', $absen_tanggal)
            ->whereIn('no_payroll', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data tgl_libur berdasarkan tanggal
        $tglLibur = TglLibur::whereIn('tgl_libur', $absen_tanggal)
            ->pluck('tgl_libur')
            ->toArray();

        $pegawaiData = [];
        $shift3_total = 0;
        $shift2_total = 0;
        $uml2_total = 0;
        $uml1_total = 0;
        foreach ($pegawai as $peg) {
            $pegawaiAbsen = $absen->where('no_reg', $peg->no_payroll);

            // Tambahkan tanggal yang tidak ada dalam database ke dalam koleksi absen
            $missing_tanggal = array_diff($daftar_tanggal, $pegawaiAbsen->pluck('tanggal')->toArray());

            foreach ($missing_tanggal as $tanggal) {
                $tanggalObj = Carbon::parse($tanggal);

                $newAbsen = [
                    'tanggal' => $tanggalObj,
                    'masuk' => '',
                    'keluar' => '',
                    'lembur' => '',
                    'ket' => $tanggalObj->isSaturday() ? 'Sabtu' : ($tanggalObj->isSunday() ? 'Minggu' : ''),
                ];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $newAbsen['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $newAbsen['ket'] = 'on';
                    }
                }

                if (in_array($tanggal, $tglLibur)) {
                    $newAbsen['ket'] = 'LN';
                } else {
                    $newAbsen['ket'] = $newAbsen['ket'] ?: '';
                }

                $pegawaiAbsen->push($newAbsen);
            }

            // Urutkan kembali koleksi absen berdasarkan tanggal
            $pegawaiAbsen = $pegawaiAbsen->sortBy('tanggal');

            $jumlah_hari = 0;
            $uml1 = 0; // Jumlah hari biasa atau hari libur dengan kondisi on
            $uml2 = 0; // Jumlah hari biasa atau hari libur dengan kondisi off
            $shift2 = 0;
            $shift3 = 0;
            $total_lembur = 0; // Inisialisasi variabel total_lembur di awal

            foreach ($pegawaiAbsen as &$item) {
                $tanggal = $item['tanggal'];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $item['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $item['ket'] = 'on';
                    }
                } else {
                    if (in_array($tanggal, $tglLibur)) {
                        $item['ket'] = 'LN';
                    } else {
                        $item['ket'] = $item['ket'] ?: '';
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $jumlah_hari++;
                }

                $absenData = $absen_d
                    ->where('tgl_absen', $tanggal)
                    ->where('no_reg', $peg->no_payroll)
                    ->first();

                if ($absenData) {
                    $item['ket'] = $absenData->jns_absen;
                }

                $masuk = Carbon::parse($item['masuk']);
                $keluar = Carbon::parse($item['keluar']);

                $lemburData = $lembur
                    ->where('ot_dat', $tanggal)
                    ->where('no_payroll', $peg->no_payroll)
                    ->first();

                // Menghitung lembur
                if ($lemburData) {
                    $start = Carbon::parse($lemburData->ot_hrb);
                    $end = Carbon::parse($lemburData->ot_hre);

                    $start_convert = $start->hour * 60 + $start->minute; // Konversi ke menit
                    $end_convert = $end->hour * 60 + $end->minute; // Konversi ke menit
                    $masuk_convert = $masuk->hour * 60 + $masuk->minute; // Konversi ke menit
                    $keluar_convert = $keluar->hour * 60 + $keluar->minute; // Konversi ke menit

                    if ($start_convert >= $end_convert) {
                        $end_convert = $end_convert + 1440;
                    } else {
                        $menit_lembur = $end_convert - $start_convert;
                    }
                    if ($masuk_convert >= $keluar_convert) {
                        $keluar_convert = $keluar_convert + 1440;
                    }

                    // periksa jam masuk dan jam mulai lembur
                    if ($masuk_convert >= $start_convert) {
                        $start = $masuk_convert; // Mulai hitung lembur dari waktu masuk
                    } else {
                        $start = $start_convert;
                    }

                    // Periksa apakah lembur berakhir setelah waktu keluar
                    if ($end_convert >= $keluar_convert) {
                        $end = $keluar_convert; // Akhiri hitungan lembur pada waktu keluar
                    } else {
                        $end = $end_convert;
                    }

                    $lembur_a = $end - $start;
                    $lemburHours = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value
                    $lembur_hours_asli = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value

                    if ($lemburHours > 5) {
                        $lemburHours -= 0.5;
                    }
                    $lembur_asli = $lembur_hours_asli;

                    // Menghitung lembur berdasarkan kondisi
                    if ($item['ket'] == 'on' && (date('N', strtotime($tanggalObj)) == 6 || date('N', strtotime($tanggalObj)) == 7)) {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    } elseif ($item['ket'] == 'LN' || $item['ket'] == 'off') {
                        $lemburHours *= 2;
                    } else {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    }

                    $item['lembur'] = $lembur_asli;
                    $item['total_lembur'] = $lemburHours; // Menyimpan total lembur pada item absen
                    $total_lembur += $lemburHours;
                }

                $tgl = Carbon::parse($tanggal);

                // Hitung jumlah hari kerja (tidak termasuk hari libur)
                if ((!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E'])) || $item['ket'] == 'on') {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if ($masuk_time->hour < 12 && $keluar_time->between(Carbon::parse('17:45'), Carbon::parse('18:30'))) {
                        // Periksa apakah hari ini bukan Sabtu atau Minggu
                        if (!$tgl->isWeekend()) {
                            $uml1++;
                            $uml1_total++;
                        }
                    }
                }

                // Hitung jumlah hari uml2
                if (!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E']) && (in_array($tgl->dayOfWeek, [0, 6]) || $item['ket'] == 'LN' || $tgl->isWeekend() || $item['ket'] == 'off') && $lemburHours < 6) {
                    $uml2++;
                    $uml2_total++;
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('18:00', '23:59') && $keluar_time->isBetween('05:00', '11:00')) || ($masuk_time->isBetween('13:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift3++;
                        $shift3_total++;
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('06:00', '17:00') && $keluar_time->isBetween('21:00', '23:59')) || ($masuk_time->isBetween('12:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift2++;
                        $shift2_total++;
                    }
                }
            }

            $daftar_tanggal_absen = $pegawaiAbsen->pluck('tanggal')->toArray();

            foreach ($tdkabsen as $tdk) {
                $tanggal = $tdk->ta_tgl;
                $status = $tdk->status;

                foreach ($pegawaiAbsen as &$item) {
                    $itemTanggal = Carbon::parse($item['tanggal']);

                    if ($itemTanggal->format('Y-m-d') === $tanggal) {
                        $item['ket'] = $status;
                        break;
                    }
                }
            }

            $pegawaiData[] = [
                'pegawai' => $peg,
                'absen' => $pegawaiAbsen,
                'jumlah_hari' => $jumlah_hari,
                'total_lembur' => $total_lembur,
                'uml1' => $uml1,
                'uml2' => $uml2,
                'shift2' => $shift2,
                'shift3' => $shift3,
            ];
        
        }

        return view('../hr/dashboard/reportabsen/rekapgaji',[
            'shift3' => $shift3,
            'shift2' => $shift2,
            'uml2' => $uml2,
            'uml1' => $uml1,
            'pegawaiData' => $pegawaiData,
            'tgl_awal' => $taw,
            'tgl_akhir' => $tak,
            'total_lembur' => $total_lembur,

        ]);
    }

    public function uraianlembur_print(Request $request)
    {
        set_time_limit(500);
        $tgl_awal = Carbon::parse($request->tgl_awal);
        $tgl_akhir = Carbon::parse($request->tgl_akhir);

        $taw = Carbon::parse($request->tgl_awal)->format('d-m-Y');
        $tak = Carbon::parse($request->tgl_akhir)->format('d-m-Y');

        $daftar_tanggal = [];
        $jumlah_hari = $tgl_akhir->diffInDays($tgl_awal);

        for ($i = 0; $i <= $jumlah_hari; $i++) {
            $daftar_tanggal[] = $tgl_awal
                ->copy()
                ->addDays($i)
                ->format('Y-m-d');
        }

        $nik = $request->no_payroll;

        $pegawaiQuery = Pegawai::where(function ($query) {
            $query->whereNull('tgl_keluar')
                  ->orWhere('tgl_keluar', '');
        })
        ->where('bagian', '!=', 'DIREKSI')
        ->orderBy('no_payroll', 'asc');
        
        if ($nik) {
            $pegawaiQuery->where('no_payroll', $nik);
        }

        $pegawai = $pegawaiQuery->get(); // Mengambil daftar pegawai

        $pegawaiData = [];

        // Mengumpulkan semua nomor registrasi pegawai
        $noRegistrasiPegawai = $pegawai->pluck('no_payroll')->toArray();

        // Mengambil data absen pegawai
        $absen = Presensi::whereIn('no_reg', $noRegistrasiPegawai)
            ->whereIn('tanggal', $daftar_tanggal)
            ->orderBy('tanggal', 'asc')
            ->get();

        // Mengumpulkan semua tanggal absen
        $absen_tanggal = $absen->pluck('tanggal')->toArray();

        // Mengumpulkan data onoff_tg berdasarkan tanggal
        $onoff_tg = onoff_tg::whereIn('tgl_off', $absen_tanggal)
            ->orWhereIn('tgl_on', $absen_tanggal)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model pertama tanpa absen_h
        $absen_d = absen_d::whereIn('tgl_absen', $absen_tanggal)
            ->whereIn('no_reg', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model kedua dengan absen_h
        // $absen_d = absen_d::join('absen_hs', 'absen_ds.int_absen', '=', 'absen_hs.int_absen')
        // ->whereIn('absen_ds.tgl_absen', $absen_tanggal)
        // ->get();

        // Mengumpulkan data tdkabsen berdasarkan nomor registrasi pegawai dan tanggal absen
        $tdkabsen = Tdkabsen::whereIn('no_payroll', $noRegistrasiPegawai)
            ->whereIn('ta_tgl', $absen_tanggal)
            ->get();

        // Mengumpulkan data lembur berdasarkan tanggal dan nomor registrasi pegawai
        $lembur = overtime::whereIn('ot_dat', $absen_tanggal)
            ->whereIn('no_payroll', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data tgl_libur berdasarkan tanggal
        $tglLibur = TglLibur::whereIn('tgl_libur', $absen_tanggal)
            ->pluck('tgl_libur')
            ->toArray();

        $pegawaiData = [];
        $shift3_total = 0;
        $shift2_total = 0;
        $uml2_total = 0;
        $uml1_total = 0;
        foreach ($pegawai as $peg) {
            $pegawaiAbsen = $absen->where('no_reg', $peg->no_payroll);

            // Tambahkan tanggal yang tidak ada dalam database ke dalam koleksi absen
            $missing_tanggal = array_diff($daftar_tanggal, $pegawaiAbsen->pluck('tanggal')->toArray());

            foreach ($missing_tanggal as $tanggal) {
                $tanggalObj = Carbon::parse($tanggal);

                $newAbsen = [
                    'tanggal' => $tanggalObj,
                    'masuk' => '',
                    'keluar' => '',
                    'lembur' => '',
                    'ket' => $tanggalObj->isSaturday() ? 'Sabtu' : ($tanggalObj->isSunday() ? 'Minggu' : ''),
                ];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $newAbsen['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $newAbsen['ket'] = 'on';
                    }
                }

                if (in_array($tanggal, $tglLibur)) {
                    $newAbsen['ket'] = 'LN';
                } else {
                    $newAbsen['ket'] = $newAbsen['ket'] ?: '';
                }

                $pegawaiAbsen->push($newAbsen);
            }

            // Urutkan kembali koleksi absen berdasarkan tanggal
            $pegawaiAbsen = $pegawaiAbsen->sortBy('tanggal');

            $jumlah_hari = 0;
            $uml1 = 0; // Jumlah hari biasa atau hari libur dengan kondisi on
            $uml2 = 0; // Jumlah hari biasa atau hari libur dengan kondisi off
            $shift2 = 0;
            $shift3 = 0;
            $total_lembur = 0; // Inisialisasi variabel total_lembur di awal

            foreach ($pegawaiAbsen as &$item) {
                $tanggal = $item['tanggal'];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $item['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $item['ket'] = 'on';
                    }
                } else {
                    if (in_array($tanggal, $tglLibur)) {
                        $item['ket'] = 'LN';
                    } else {
                        $item['ket'] = $item['ket'] ?: '';
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $jumlah_hari++;
                }

                $absenData = $absen_d
                    ->where('tgl_absen', $tanggal)
                    ->where('no_reg', $peg->no_payroll)
                    ->first();

                if ($absenData) {
                    $item['ket'] = $absenData->jns_absen;
                }

                $masuk = Carbon::parse($item['masuk']);
                $keluar = Carbon::parse($item['keluar']);

                $lemburData = $lembur
                    ->where('ot_dat', $tanggal)
                    ->where('no_payroll', $peg->no_payroll)
                    ->first();

                // Menghitung lembur
                if ($lemburData) {
                    $start = Carbon::parse($lemburData->ot_hrb);
                    $end = Carbon::parse($lemburData->ot_hre);

                    $startq = Carbon::parse($lemburData->ot_hrb)->format('H:i');
                    $endq = Carbon::parse($lemburData->ot_hre)->format('H:i');

                    $item['start'] = $startq;
                    $item['end'] = $endq;

                    $start_convert = $start->hour * 60 + $start->minute; // Konversi ke menit
                    $end_convert = $end->hour * 60 + $end->minute; // Konversi ke menit
                    $masuk_convert = $masuk->hour * 60 + $masuk->minute; // Konversi ke menit
                    $keluar_convert = $keluar->hour * 60 + $keluar->minute; // Konversi ke menit

                    if ($start_convert >= $end_convert) {
                        $end_convert = $end_convert + 1440;
                    } else {
                        $menit_lembur = $end_convert - $start_convert;
                    }
                    if ($masuk_convert >= $keluar_convert) {
                        $keluar_convert = $keluar_convert + 1440;
                    }

                    // periksa jam masuk dan jam mulai lembur
                    if ($masuk_convert >= $start_convert) {
                        $start = $masuk_convert; // Mulai hitung lembur dari waktu masuk
                    } else {
                        $start = $start_convert;
                    }

                    // Periksa apakah lembur berakhir setelah waktu keluar
                    if ($end_convert >= $keluar_convert) {
                        $end = $keluar_convert; // Akhiri hitungan lembur pada waktu keluar
                    } else {
                        $end = $end_convert;
                    }

                    $lembur_a = $end - $start;
                    $lemburHours = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value
                    $lembur_hours_asli = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value

                    if ($lemburHours > 5) {
                        $lemburHours -= 0.5;
                    }
                    $lembur_asli = $lembur_hours_asli;

                    // Menghitung lembur berdasarkan kondisi
                    if ($item['ket'] == 'on' && (date('N', strtotime($tanggalObj)) == 6 || date('N', strtotime($tanggalObj)) == 7)) {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    } elseif ($item['ket'] == 'LN' || $item['ket'] == 'off') {
                        $lemburHours *= 2;
                    } else {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    }


                    $item['lembur'] = $lembur_hours_asli;
                    $item['lembur_total'] = $lemburHours;
                    $total_lembur += $lemburHours;
                }

                $tgl = Carbon::parse($tanggal);

                // Hitung jumlah hari kerja (tidak termasuk hari libur)
                if ((!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E'])) || $item['ket'] == 'on') {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if ($masuk_time->hour < 12 && $keluar_time->between(Carbon::parse('17:45'), Carbon::parse('18:30'))) {
                        // Periksa apakah hari ini bukan Sabtu atau Minggu
                        if (!$tgl->isWeekend()) {
                            $uml1++;
                            $uml1_total++;
                        }
                    }
                }

                // Hitung jumlah hari uml2
                if (!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E']) && (in_array($tgl->dayOfWeek, [0, 6]) || $item['ket'] == 'LN' || $tgl->isWeekend() || $item['ket'] == 'off') && $lemburHours < 6) {
                    $uml2++;
                    $uml2_total++;
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('18:00', '23:59') && $keluar_time->isBetween('05:00', '11:00')) || ($masuk_time->isBetween('13:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift3++;
                        $shift3_total++;
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('06:00', '17:00') && $keluar_time->isBetween('21:00', '23:59')) || ($masuk_time->isBetween('12:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift2++;
                        $shift2_total++;
                    }
                }
            }

            $daftar_tanggal_absen = $pegawaiAbsen->pluck('tanggal')->toArray();

            foreach ($tdkabsen as $tdk) {
                $tanggal = $tdk->ta_tgl;
                $status = $tdk->status;

                foreach ($pegawaiAbsen as &$item) {
                    $itemTanggal = Carbon::parse($item['tanggal']);

                    if ($itemTanggal->format('Y-m-d') === $tanggal) {
                        $item['ket'] = $status;
                        break;
                    }
                }
            }

            $pegawaiData[] = [
                'pegawai' => $peg,
                'absen' => $pegawaiAbsen,
                'jumlah_hari' => $jumlah_hari,
                'total_lembur' => $total_lembur,
                'uml1' => $uml1,
                'uml2' => $uml2,
                'shift2' => $shift2,
                'shift3' => $shift3,
            ];
        }

        $pdf = Pdf::loadview('/hr/dashboard/reportabsen/uraianlembur_print',[
            'shift3_total' => $shift3_total,
            'shift2_total' => $shift2_total,
            'uml2_total' => $uml2_total,
            'uml1_total' => $uml1_total,
            'pegawaiData' => $pegawaiData,
            'tgl_awal' => $taw,
            'tgl_akhir' => $tak,
        ]);
        return $pdf->setPaper('a4', 'potrait')->stream('uraianlembur.pdf');
    }

    public function rekapgaji_print(Request $request)
    {
        set_time_limit(500);
        $tgl_awal = Carbon::parse($request->tgl_awal);
        $tgl_akhir = Carbon::parse($request->tgl_akhir);

        $taw = Carbon::parse($request->tgl_awal)->format('d-m-Y');
        $tak = Carbon::parse($request->tgl_akhir)->format('d-m-Y');

        $daftar_tanggal = [];
        $jumlah_hari = $tgl_akhir->diffInDays($tgl_awal);

        for ($i = 0; $i <= $jumlah_hari; $i++) {
            $daftar_tanggal[] = $tgl_awal
                ->copy()
                ->addDays($i)
                ->format('Y-m-d');
        }

        $nik = $request->no_payroll;

        $pegawaiQuery = Pegawai::where(function ($query) {
            $query->whereNull('tgl_keluar')
                  ->orWhere('tgl_keluar', '');
        })
        ->where('bagian', '!=', 'DIREKSI')
        ->orderBy('no_payroll', 'asc');
        
        if ($nik) {
            $pegawaiQuery->where('no_payroll', $nik);
        }

        $pegawai = $pegawaiQuery->get(); // Mengambil daftar pegawai

        $pegawaiData = [];

        // Mengumpulkan semua nomor registrasi pegawai
        $noRegistrasiPegawai = $pegawai->pluck('no_payroll')->toArray();

        // Mengambil data absen pegawai
        $absen = Presensi::whereIn('no_reg', $noRegistrasiPegawai)
            ->whereIn('tanggal', $daftar_tanggal)
            ->orderBy('tanggal', 'asc')
            ->get();

        // Mengumpulkan semua tanggal absen
        $absen_tanggal = $absen->pluck('tanggal')->toArray();

        // Mengumpulkan data onoff_tg berdasarkan tanggal
        $onoff_tg = onoff_tg::whereIn('tgl_off', $absen_tanggal)
            ->orWhereIn('tgl_on', $absen_tanggal)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model pertama tanpa absen_h
        $absen_d = absen_d::whereIn('tgl_absen', $absen_tanggal)
            ->whereIn('no_reg', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data absen_d berdasarkan tanggal dan nomor registrasi pegawai model kedua dengan absen_h
        // $absen_d = absen_d::join('absen_hs', 'absen_ds.int_absen', '=', 'absen_hs.int_absen')
        // ->whereIn('absen_ds.tgl_absen', $absen_tanggal)
        // ->get();

        // Mengumpulkan data tdkabsen berdasarkan nomor registrasi pegawai dan tanggal absen
        $tdkabsen = Tdkabsen::whereIn('no_payroll', $noRegistrasiPegawai)
            ->whereIn('ta_tgl', $absen_tanggal)
            ->get();

        // Mengumpulkan data lembur berdasarkan tanggal dan nomor registrasi pegawai
        $lembur = overtime::whereIn('ot_dat', $absen_tanggal)
            ->whereIn('no_payroll', $noRegistrasiPegawai)
            ->get();

        // Mengumpulkan data tgl_libur berdasarkan tanggal
        $tglLibur = TglLibur::whereIn('tgl_libur', $absen_tanggal)
            ->pluck('tgl_libur')
            ->toArray();

        $pegawaiData = [];
        $shift3_total = 0;
        $shift2_total = 0;
        $uml2_total = 0;
        $uml1_total = 0;
        foreach ($pegawai as $peg) {
            $pegawaiAbsen = $absen->where('no_reg', $peg->no_payroll);

            // Tambahkan tanggal yang tidak ada dalam database ke dalam koleksi absen
            $missing_tanggal = array_diff($daftar_tanggal, $pegawaiAbsen->pluck('tanggal')->toArray());

            foreach ($missing_tanggal as $tanggal) {
                $tanggalObj = Carbon::parse($tanggal);

                $newAbsen = [
                    'tanggal' => $tanggalObj,
                    'masuk' => '',
                    'keluar' => '',
                    'lembur' => '',
                    'ket' => $tanggalObj->isSaturday() ? 'Sabtu' : ($tanggalObj->isSunday() ? 'Minggu' : ''),
                ];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $newAbsen['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $newAbsen['ket'] = 'on';
                    }
                }

                if (in_array($tanggal, $tglLibur)) {
                    $newAbsen['ket'] = 'LN';
                } else {
                    $newAbsen['ket'] = $newAbsen['ket'] ?: '';
                }

                $pegawaiAbsen->push($newAbsen);
            }

            // Urutkan kembali koleksi absen berdasarkan tanggal
            $pegawaiAbsen = $pegawaiAbsen->sortBy('tanggal');

            $jumlah_hari = 0;
            $uml1 = 0; // Jumlah hari biasa atau hari libur dengan kondisi on
            $uml2 = 0; // Jumlah hari biasa atau hari libur dengan kondisi off
            $shift2 = 0;
            $shift3 = 0;
            $total_lembur = 0; // Inisialisasi variabel total_lembur di awal

            foreach ($pegawaiAbsen as &$item) {
                $tanggal = $item['tanggal'];

                $onoff = $onoff_tg->firstWhere('tgl_off', $tanggal) ?? $onoff_tg->firstWhere('tgl_on', $tanggal);

                if ($onoff) {
                    if ($onoff->tgl_off == $tanggal) {
                        $item['ket'] = 'off';
                    } elseif ($onoff->tgl_on == $tanggal) {
                        $item['ket'] = 'on';
                    }
                } else {
                    if (in_array($tanggal, $tglLibur)) {
                        $item['ket'] = 'LN';
                    } else {
                        $item['ket'] = $item['ket'] ?: '';
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $jumlah_hari++;
                }

                $absenData = $absen_d
                    ->where('tgl_absen', $tanggal)
                    ->where('no_reg', $peg->no_payroll)
                    ->first();

                if ($absenData) {
                    $item['ket'] = $absenData->jns_absen;
                }

                $masuk = Carbon::parse($item['masuk']);
                $keluar = Carbon::parse($item['keluar']);

                $lemburData = $lembur
                    ->where('ot_dat', $tanggal)
                    ->where('no_payroll', $peg->no_payroll)
                    ->first();

                // Menghitung lembur
                if ($lemburData) {
                    $start = Carbon::parse($lemburData->ot_hrb);
                    $end = Carbon::parse($lemburData->ot_hre);

                    $start_convert = $start->hour * 60 + $start->minute; // Konversi ke menit
                    $end_convert = $end->hour * 60 + $end->minute; // Konversi ke menit
                    $masuk_convert = $masuk->hour * 60 + $masuk->minute; // Konversi ke menit
                    $keluar_convert = $keluar->hour * 60 + $keluar->minute; // Konversi ke menit

                    if ($start_convert >= $end_convert) {
                        $end_convert = $end_convert + 1440;
                    } else {
                        $menit_lembur = $end_convert - $start_convert;
                    }
                    if ($masuk_convert >= $keluar_convert) {
                        $keluar_convert = $keluar_convert + 1440;
                    }

                    // periksa jam masuk dan jam mulai lembur
                    if ($masuk_convert >= $start_convert) {
                        $start = $masuk_convert; // Mulai hitung lembur dari waktu masuk
                    } else {
                        $start = $start_convert;
                    }

                    // Periksa apakah lembur berakhir setelah waktu keluar
                    if ($end_convert >= $keluar_convert) {
                        $end = $keluar_convert; // Akhiri hitungan lembur pada waktu keluar
                    } else {
                        $end = $end_convert;
                    }

                    $lembur_a = $end - $start;
                    $lemburHours = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value
                    $lembur_hours_asli = round(($lembur_a / 60) * 2) / 2; // Convert minutes to hours and round to the nearest 0.5 value

                    if ($lemburHours > 5) {
                        $lemburHours -= 0.5;
                    }
                    $lembur_asli = $lembur_hours_asli;

                    // Menghitung lembur berdasarkan kondisi
                    if ($item['ket'] == 'on' && (date('N', strtotime($tanggalObj)) == 6 || date('N', strtotime($tanggalObj)) == 7)) {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    } elseif ($item['ket'] == 'LN' || $item['ket'] == 'off') {
                        $lemburHours *= 2;
                    } else {
                        $lemburHours *= 2;
                        $lemburHours -= 0.5;
                    }

                    $item['lembur'] = $lembur_asli;
                    $item['total_lembur'] = $lemburHours; // Menyimpan total lembur pada item absen
                    $total_lembur += $lemburHours;
                }

                $tgl = Carbon::parse($tanggal);

                // Hitung jumlah hari kerja (tidak termasuk hari libur)
                if ((!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E'])) || $item['ket'] == 'on') {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if ($masuk_time->hour < 12 && $keluar_time->between(Carbon::parse('17:45'), Carbon::parse('18:30'))) {
                        // Periksa apakah hari ini bukan Sabtu atau Minggu
                        if (!$tgl->isWeekend()) {
                            $uml1++;
                            $uml1_total++;
                        }
                    }
                }

                // Hitung jumlah hari uml2
                if (!empty($item['lembur']) && in_array($peg->golongan, ['A', 'B', 'C', 'D', 'E']) && (in_array($tgl->dayOfWeek, [0, 6]) || $item['ket'] == 'LN' || $tgl->isWeekend() || $item['ket'] == 'off') && $lemburHours < 6) {
                    $uml2++;
                    $uml2_total++;
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('18:00', '23:59') && $keluar_time->isBetween('05:00', '11:00')) || ($masuk_time->isBetween('13:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift3++;
                        $shift3_total++;
                    }
                }

                if (!empty($item['masuk']) && !empty($item['keluar'])) {
                    $masuk_time = Carbon::parse($item['masuk']);
                    $keluar_time = Carbon::parse($item['keluar']);

                    if (($masuk_time->isBetween('06:00', '17:00') && $keluar_time->isBetween('21:00', '23:59')) || ($masuk_time->isBetween('12:00', '17:00') && $keluar_time->isBetween('05:00', '11:00'))) {
                        $shift2++;
                        $shift2_total++;
                    }
                }
            }

            $daftar_tanggal_absen = $pegawaiAbsen->pluck('tanggal')->toArray();

            foreach ($tdkabsen as $tdk) {
                $tanggal = $tdk->ta_tgl;
                $status = $tdk->status;

                foreach ($pegawaiAbsen as &$item) {
                    $itemTanggal = Carbon::parse($item['tanggal']);

                    if ($itemTanggal->format('Y-m-d') === $tanggal) {
                        $item['ket'] = $status;
                        break;
                    }
                }
            }

            $pegawaiData[] = [
                'pegawai' => $peg,
                'absen' => $pegawaiAbsen,
                'jumlah_hari' => $jumlah_hari,
                'total_lembur' => $total_lembur,
                'uml1' => $uml1,
                'uml2' => $uml2,
                'shift2' => $shift2,
                'shift3' => $shift3,
            ];
        }

        $pdf = Pdf::loadview('/hr/dashboard/reportabsen/rekapgaji_print', [
            'shift3_total' => $shift3_total,
            'shift2_total' => $shift2_total,
            'uml2_total' => $uml2_total,
            'uml1_total' => $uml1_total,
            'pegawaiData' => $pegawaiData,
            'tgl_awal' => $taw,
            'tgl_akhir' => $tak,
        ]);
        return $pdf->setPaper('a4', 'potrait')->stream('rekapgaji.pdf');
    }
}



<?php $__env->startSection('content'); ?>
    <div class="section  px-4">
        <div class="row ">
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-2 ">
                        <a href="/hr/dashboard/training/tr/create"  >
                            <button class="btn btn-sm bg-info">Tambah</button>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-1">
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center">
                        <p><?php echo e(Session::get('success')); ?></p>
                    </div>
                <?php endif; ?>
                <div class="card ">
                    <div class="table  ">
                        <table  class="table align-items-center mb-0 border-success table-striped">
                            <thead class=" bg-secondary text-light shadow font-weight-bolder  ">
                                <tr>
                                    <td>No Pelatihan</td>
                                    <td>Pemateri</td>
                                    <td >Pelatihan</td>
                                    <td>Kompetensi</td>
                                    <td>Tanggal</td>
                                    <td>Tipe</td>
                                    <td>Option</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="bg-gradient-light   ">
                                        <td><?php echo e($item->train_cod); ?></td>
                                        <td><?php echo e($item->pemateri); ?></td>
                                        <td><?php echo e($item->pltran_nam); ?></td>
                                        <td><?php echo e($item->kompetensi); ?></td>
                                        <td><?php echo e($item->train_dat); ?></td>
                                        <td><?php echo e($item->tipe); ?></td>
                                        <td><a href="<?php echo e(route('hr.training.view', $item->id)); ?>"
                                                class="btn btn-sm btn-primary ">Lihat</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="alert alert-danger">
                                        Data Post belum Tersedia.
                                    </div>
                                <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('hr.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/tr/list.blade.php ENDPATH**/ ?>
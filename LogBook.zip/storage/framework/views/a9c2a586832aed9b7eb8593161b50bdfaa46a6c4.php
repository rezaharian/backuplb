<!DOCTYPE html>
<html>

<head>
    <title>Mesin</title>

    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 12pt;
        }
    </style>
</head>

<body>


    <br>
    <strong style="font-family: Arial, Helvetica, sans-serif;">
        <center>Permasalahan Mesin</center>
    </strong>
    <br>



    <div>
        <div>
            <table border="" style="background: rgb(255, 255, 255); border:0;   font-family: Arial, Helvetica, sans-serif;">
                <tr>
                    <td style="width:20%; ">Kode </td>
                    <td>  <?php echo e($view->prob_cod); ?> </td>
                </tr>
                <tr>
                    <td>Line </td>

                    <td>  <?php echo e($view->line); ?> </td>
                </tr>
                <tr>
                    <td>Unit </td>

                    <td>  <?php echo e($view->unitmesin); ?> </td>
                </tr>
                <tr>
                    <td>Tgl Input </td>

                    <td>  <?php echo e($view->tgl_input); ?> </td>
                </tr>
                <tr>
                    <td>Masalah </td>

                    <td>  <?php echo e($view->masalah); ?>  </td>
                </tr>
                <br>
                <tr>
                    <td>Penyebab </td>

                    <td>  <?php echo e($view_d->penyebab); ?> </td>
                </tr>
                <tr>
                    <td>Tgl Perbaikan </td>

                    <td>  <?php echo e($view_d->tgl_rpr); ?> </td>
                </tr>
                <tr>
                    <td>Perbaikan </td>

                    <td>  <?php echo e($view_d->perbaikan); ?> </td>
                </tr>
                <tr>
                    <td>Tgl Pencegahan </td>

                    <td>  <?php echo e($view_d->tgl_pre); ?> </td>
                </tr>
                <tr>
                    <td> Pencegahan </td>

                    <td>  <?php echo e($view_d->pencegahan); ?> </td>
                </tr>
            </table>
            <h3>Gambar :</h3>
            <table>
                <br>
                <br>
                <br>
                <tr>
                    <td>
                        <img src="<?php echo e(public_path("/image/".$view->img_pro01 )); ?>" alt="" style="width: 150px; ">
                        <img src="<?php echo e(public_path("/image/".$view->img_pro02 )); ?>" alt="" style="width: 150px; ">
                        <img src="<?php echo e(public_path("/image/".$view->img_pro03 )); ?>" alt="" style="width: 150px; ">
                        <img src="<?php echo e(public_path("/image/".$view->img_pro04 )); ?>" alt="" style="width: 150px; ">
                    </td>
                </tr>
            </table>
        </div>

    </div>


</body>

</html>
<?php /**PATH C:\App\LogBook\resources\views/qc/dashboard/problemmsn/print.blade.php ENDPATH**/ ?>
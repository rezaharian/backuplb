

<?php $__env->startSection('content'); ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <table class="table">
                    <tr>
                        <div class="row ms-3 bg-gradien-light  pt-3 text-center item-center justify-content-center">
                            <div class="col-md-2">
                                <a href="<?php echo e(route('hr.kompetensi.delete', $view->id)); ?>" onclick="return confirm('Apakah Anda Yakin ?');" class="btn btn-sm btn-danger">Delete</a>
                            </div>
                            <div class="col-md-2 ms-2">
                                <a href="<?php echo e(route('hr.kompetensi.edit', $view->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
    
                            </div>
    
                        </div>
                        
                    </tr>
                    <tr>
                        <td><label for="example-text-input" class="form-control-label">NO Kompetensi</label></td>
                        <td><input disabled class="form-control" type="text" name="train_cod"
                                value="<?php echo e($view->kompe_cod); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td><label for="example-text-input" class="form-control-label">bagian</label></td>
                        <td><input disabled class="form-control" type="text" name="tempat" value="<?php echo e($view->bagian); ?>">
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        </table>

        </div>

        <div class="row">
            <div class="col-lg-12">
                <table class="table" style="width:100%;">
                    <thead class="bg-secondary text-light">
                        <th>No.</th>
                        <th>Kompetensi</th>
                        <th>jenis Kompetensi</th>
                    </thead>
                    <tbody id="tbl-barang-body">
                        <?php $__empty_1 = true; $__currentLoopData = $view_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($item->kompetensi); ?></td>
                                <td><?php echo e($item->jenis); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td>
                                <h1>data tidak ada</h1>
                            </td>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>

        <div class="row btnSave" style="display:none;">
            <div class="col-lg-12">
                <button type="submit" class="btn btn-primary">SIMPAN </button>
            </div>
        </div>

        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hr.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/kompetensi/view.blade.php ENDPATH**/ ?>
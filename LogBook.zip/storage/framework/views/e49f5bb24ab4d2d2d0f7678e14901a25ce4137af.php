

<?php $__env->startSection('content'); ?>


<h3>Halaaman Operator Produksi</h3>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('op.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/op/dashboard/problemmsn/produksi.blade.php ENDPATH**/ ?>
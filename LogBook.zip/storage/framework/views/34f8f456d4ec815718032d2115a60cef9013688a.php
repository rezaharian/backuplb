<!DOCTYPE html>
<html>
<head>
<title>Laravel 9 Add/remove multiple input fields dynamically using Jquery</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/js/bootstrap.min.js"></script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
<div class="container">
<div class="card mt-3">
<div class="card-header"><h2>Add/remove Multiple Input Todo Fields Dynamically using Jquery In Laravel 9</h2></div>
<div class="card-body">
<form action="<?php echo e(url('add-remove-multiple-input-fields')); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
<div class="alert alert-success text-center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
<p><?php echo e(Session::get('success')); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered" id="dynamicAddRemove">  
<tr>
<th>NoID</th>
<th>Name</th>
<th>Action</th>
</tr>
<tr>  
<td><input type="text" name="moreFields[0][id]" placeholder="Enter title" id="auto" /></td>  
<td><input type="text" name="moreFields[0][nama]" placeholder="Enter title" id="auto" /></td>  
<td><button type="button" name="add" id="add-btn" class="btn btn-success">Add More</button></td>  
</tr>  
</table> 
<button type="submit" class="btn btn-success">Save</button>
</form>
</div>
</div>
</div>
<script type="text/javascript">
var i = 0;
$("#add-btn").click(function(){
++i; 
$("#dynamicAddRemove").append('<tr><td><input type="text" name="moreFields['+i+'][id]" placeholder="Enter title" id="auto" class="auto" /></td><td><input type="text" name="moreFields['+i+'][nama]" placeholder="Enter title" class="auto" /></td><td><button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>');
});
$(document).on('click', '.remove-tr', function(){  
$(this).parents('tr').remove();
});  
</script>
<link rel="stylesheet" type="text/css"
href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-alpha1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>


      <script type="text/javascript">
      $('#auto').select2({
      placeholder: 'Select pegawai',
      ajax: {
          url: '/autocomplete',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
              return {
                  results: $.map(data, function (item) {
                      return {
                          text: item.nama,
                          id: item.id,
                        
                      }
                  })
              };
          },
          cache: true
      }
  });

      
      </script>
</body>
</html><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/tr/cb.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="section">
        <div class="row">
            <div class="row text-center mb-3">
                <h5 class="font-weight-bolder mb-0">Daftar/List Kerusakan/Masalah Mesin</h5>
            </div>
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-1 ">
                    </div>
                    <div class="col-md-2 ">
                        <form class="form-group"action="<?php echo e(route('problemmsn.index')); ?>" method="GET">
                            <select class="form-select  font-weight-bold text-secondary  rounded border-primary"
                                name="cariline" placeholder="line ">
                                <option selected value="">SEMUA</option>
                                <?php $__currentLoopData = $datal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->line); ?>"><?php echo e($item->line); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="col-md-2 ">
                        <select class="form-select  font-weight-bold text-secondary  rounded border-primary "
                            name="cariunitmsn" placeholder="unit ">
                            <option selected value="">SEMUA</option>
                            <?php $__currentLoopData = $datau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->unit_nam); ?>"><?php echo e($item->unit_nam); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" class="form-control font-weight-bold text-secondary border-primary"  name="masalah"
                            placeholder="masalah">
                    </div>
                    <div class="col-md-3">
                        <input type="text" class="form-control font-weight-bold text-secondary border-primary" name="penyebab"
                            placeholder="penyebab">
                    </div>
                    <div class="col-md-1 ">
                        <input type="submit" class="btn btn-primary border text-light" value="CARI">
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-1">
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success text-center">
                    <p><?php echo e(Session::get('success')); ?></p>
                </div>
            <?php endif; ?>
            <div class="card ">
                <div style="height:450px;overflow:auto;">
                    <table  class="  align-items-center mb-0  table-bordered border-dark">
                        <thead class=" bg-primary text-center text-light shadow font-weight-bolder sticky-top  ">
                           
                                <tr class="text-xs">
                                <th style="width: 5%;">Line</th>
                                <th style="width: 12%;">Unit Mesin</th>
                                <th style="width:15%;">Masalah</th>
                                <th  style="width:15%;">Penyebab</th>
                                <th  style="width:15%;">Perbaikan</th>
                                <th  style="width:15%;">Pencegahan</th>
                                <th  style="width:7%;">TGL</th>
                                <th style="width:7%;">No Doc</th>
                                <th  style="width:4%; text-align:center;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class=" text-xs  ">
                                    <td class="text-xs"><?php echo e($item->line); ?></td>
                                    <td><?php echo e($item->unitmesin); ?></td>
                                    <td >
                                       <?php echo e($item->masalah); ?>

                                    </td>
                                    <td>
                                       <?php echo e($item->penyebab); ?>

                                    </td>
                                    <td>
                                       <?php echo e($item->perbaikan); ?>

                                    </td>
                                    <td>
                                       <?php echo e($item->pencegahan); ?>

                                    </td>
                                    <td><?php echo e($item->tgl_input); ?></td>
                                    <td><?php echo e($item->prob_cod); ?></td>
                                    <td style="text-align: center;"><a href="<?php echo e(route('problemmsn.view_d', $item->id)); ?>">
                                    <button type="button" style="background-color: rgb(255, 255, 0); ">Lihat</button>
                                    </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="alert alert-danger">
                                    Data belum Tersedia.
                                </div>
                            <?php endif; ?>
                        </tbody>
                    </table> 
                </div>
            </div>
            </div>
        </div>
    </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('qc.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/qc/dashboard/problemmsn/index.blade.php ENDPATH**/ ?>
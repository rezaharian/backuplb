

<?php $__env->startSection('content'); ?>
    <div class="section text-xs  px-0">
        <div class="row ">
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-2 ">
                        <a href="/qc/dashboard/problemmsn/create" class="btn btn-sm btn-success">Tambah</a>
                    </div>
                </div>
            </div>
            <div class="col-md-1">
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center">
                        <p><?php echo e(Session::get('success')); ?></p>
                    </div>
                <?php endif; ?>
                <div class="card ">
                    <div style="height:450px;overflow:auto;">
                        <table  class="  align-items-center mb-0  table-bordered border-dark">
                            <thead class=" bg-primary text-center text-light shadow font-weight-bolder sticky-top  ">
                               
                                    <tr class="text-xs">
                                <td style="width:10%;">Tanggal</td>
                                <td style="width:10%;">DOC</td>
                                <td style="width:10%;">Line</td>
                                <td style="width:10%;">Unit Mesin</td>
                                <td style="width:40%;">Masalah</td>
                                <td style="width:15%;">Aksi</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $prob_h; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="bg-gradient-light   ">
                                    <td><?php echo e($item->tgl_input); ?></td>
                                    <td><?php echo e($item->prob_cod); ?></td>
                                    <td><?php echo e($item->line); ?></td>
                                    <td><?php echo e($item->unitmesin); ?></td>
                                    <td><?php echo e($item->masalah); ?></td>
                                    <td>
                                    <a href="<?php echo e(route('problemmsn.edit', $item->id)); ?>"
                                            class="btn btn-sm btn-primary ">Edit</a>
                                            <a href="<?php echo e(route('problemmsn.print_d', $item->id)); ?>"class="btn btn-sm btn-warning  " target="_blank">Print</a>
                                            <a href="<?php echo e(route('problemmsn.delete', $item->id)); ?>" onclick="return confirm('Apakah Anda Yakin ?');" class="btn btn-sm btn-danger">Hapus</a>

                                        </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="alert alert-danger">
                                    Data Post belum Tersedia.
                                </div>
                            <?php endif; ?>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('qc.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/qc/dashboard/problemmsn/list.blade.php ENDPATH**/ ?>
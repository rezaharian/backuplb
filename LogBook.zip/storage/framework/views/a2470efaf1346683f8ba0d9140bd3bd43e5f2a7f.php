

<?php $__env->startSection('content'); ?>
   
        <div class="row mt-1">
            <div class="col-md-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center">
                        <p><?php echo e(Session::get('success')); ?></p>
                    </div>
                <?php endif; ?>
               


 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('hr.dashboard.training.trainer.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/trainer/index.blade.php ENDPATH**/ ?>
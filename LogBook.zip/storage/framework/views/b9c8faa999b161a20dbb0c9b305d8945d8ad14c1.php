

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card ms-4 ">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <h5 class="font-weight-bolder">
                            <?php echo e(session('message')); ?> Shift <?php echo e($dms->shift); ?>

                        </h5>
                    </div>
                <?php endif; ?>
                <div class=" sticky-top bg-gradient-info ">

                    <div class="font-weight-bolder text-center text-light fs-5 m-2 ">
                        
                    </div>
                    <div class="row  mx-1 ">
                        <div class="col-md-1 ">
                            <form class="mt-3 "
                                action="<?php echo e(route('superadmin.delete.datacap', ['jalur_id' => $arr['jalur_id']])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn shadow btn-outline-light btn text-light "
                                    onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                    <i class="fas fa-trash "></i></button>
                            </form>



                        </div>
                        




                        
                        


                        

                        
                        
                        <div class="col-md-6 text-center">
                            


                            <div class="col-md-12   ">
                                <form class="form-group success "
                                    action="<?php echo e(url('/superadmin/dashboard/loogbokcap/insertfielddata', ['jalur_id' => $arr['jalur_id']])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row rounded border pt-2 shadow">
                                        <div class="col-md-6">

                                            <input
                                                class="form-control font-weight-bold text-secondary border-light rounded m-1"
                                                type="date" name="tanggal">
                                        </div>
                                        <div class="col-md-4">
                                            <select
                                                class="form-select mt-1 font-weight-bold text-secondary border-light rounded "
                                                name="shift">
                                                <option value="1"> Shift I</option>
                                                <option value="2"> Shift II</option>
                                                <option value="3"> Shift III</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 mt-1">
                                            <button type="submit"
                                                class="btn btn-primary btn-outline-light btn-md">Buat</button>
                                        </div>
                                    </div>

                            </div>



                            </form>
                        </div>
                        <div class="col-md-5   ">
                            <div class="row rounded border pt-1 ms-1 shadow  text-center ">
                                <div class="col-md-5 mt-2 ">
                                    <form class="form-group"
                                        action="<?php echo e(route('superadmin.index.cari.datacap', ['jalur_id' => $arr['jalur_id']])); ?>"
                                        method="GET">
                                        <input type="date" class="form-control font-weight-bold text-secondary" name="cari" placeholder="Tanggal "
                                        value="<?php echo e(old('cari')); ?>">
                                </div>
                                <div class="col-md-4 mt-2">
                                    <select class="form-select  font-weight-bold text-secondary border-light rounded "
                                        name="carit" placeholder="shift " value="<?php echo e(old('carit')); ?>">
                                        <option value="1"> Shift I</option>
                                        <option value="2"> Shift II</option>
                                        <option value="3"> Shift III</option>
                                        <option value=""> Semua</option>
                                    </select>
                                </div>
                                <div class="col-md-1 mt-2 ">
                                    <input type="submit" class="btn btn-primary border text-light" value="CARI"> 
                                </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0 text-center">
                        <table class="table align-items-center mb-0 ">
                            <thead>
                                <tr class=" ">
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">ID</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">tanggal</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Jam</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">shift</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Reset</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Reset Opt
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">awal</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">akhir</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">klk PCS</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">klk Shift
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">klk Hari</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Reset Opt
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Reset</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Awal </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Akhir</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Rntme</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Rntme Shift
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Rntme Hari
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">SPK</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">prdk</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Ket</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">opr</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder ">Opt</th>
                                </tr>
                            </thead>
                            <tbody class="table-responsive">
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->id); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->tanggal); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->etc); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->shift); ?></td>
                                        <?php if($data->reset == 'YES'): ?>
                                            <td class="text-xs font-weight-bold mb-0 bg-danger"><?php echo e($data->reset); ?>

                                            </td>
                                        <?php else: ?>
                                            <td class="text-xs font-weight-bold mb-0 bg-light"><?php echo e($data->reset); ?></td>
                                        <?php endif; ?>




                                        <td class="text-xs font-weight-bold mb-0">
                                            <a class="btn bg-gradient-danger btn-sm"
                                                href="<?php echo e(route('superadmin.reset.datacap', ['jalur_id' => $data->jalur_id, 'data' => $data->id])); ?>">R</a>
                                            <a
                                                class="btn bg-gradient-success btn-sm "href="<?php echo e(route('superadmin.batalresetpcs.datacap', ['jalur_id' => $data->jalur_id, 'data' => $data->id])); ?>">B</a>

                                        </td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->awal); ?></td>
                                        <td class="text-xs font-weight-bold mb-0 bg-gradient-light fs-6 "
                                            data-pk="<?php echo e($data->id); ?>">
                                            <a href="" class="update" data-name="akhir" data-type="text"
                                                data-pk="<?php echo e($data->id); ?>"
                                                data-title="Enter name"><?php echo e($data->akhir); ?></a>
                                        </td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->kalkulasi); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->jumlahpershift); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->jumlahperhari); ?></td>
                                        <td class="text-xs font-weight-bold mb-0">
                                            <a
                                                class="btn bg-gradient-danger btn-sm "href="<?php echo e(route('superadmin.resetwaktu.datacap', ['jalur_id' => $data->jalur_id, 'data' => $data->id])); ?>">R</a>
                                            <a
                                                class="btn bg-gradient-success btn-sm "href="<?php echo e(route('superadmin.batalresettime.datacap', ['jalur_id' => $data->jalur_id, 'data' => $data->id])); ?>">B</a>

                                        </td>

                                        <?php if($data->resetw == 'YES'): ?>
                                            <td class="text-xs font-weight-bold mb-0 bg-danger"><?php echo e($data->resetw); ?>

                                            </td>
                                        <?php else: ?>
                                            <td class="text-xs font-weight-bold mb-0 bg-light"><?php echo e($data->resetw); ?>

                                            </td>
                                        <?php endif; ?>


                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->awaljam); ?> :
                                            <?php echo e($data->awalmenit); ?></td>
                                        <td class="text-xs font-weight-bold mb-0 bg-gradient-light fs-6">
                                            <a href="" class="update" data-name="akhirjam" data-type="text"
                                                data-pk="<?php echo e($data->id); ?>"
                                                data-title="Enter name"><?php echo e($data->akhirjam); ?></a>:
                                            <a href="" class="update" data-name="akhirmenit" data-type="text"
                                                data-pk="<?php echo e($data->id); ?>"
                                                data-title="Enter name"><?php echo e($data->akhirmenit); ?></a>
                                        </td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->runtimemenit); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->runtimeshift); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->runtimehari); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->spk); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->produk); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->keterangan); ?></td>
                                        <td class="text-xs font-weight-bold mb-0"><?php echo e($data->operator); ?></td>
                                        <td class="text-xs font-weight-bold mb-0" style="width: 5%">
                                            

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                        <div class="my-4 ">
                            <?php echo e($datas->links()); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $prev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
        <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/js/jquery-editable-poshytip.min.js">
        </script>


        <script>
            function kali() {
                var awal = document.getElementById('awal').value;
                var akhir = document.getElementById('akhir').value;
                var kalkulasi = document.getElementById('kalkulasi').value;
                var jumlahpershift = document.getElementById('jumlahpershift').value;
                var jumlahperhari = document.getElementById('jumlahperhari').value;
                var awaljam = document.getElementById('awaljam').value;
                var awalmenit = document.getElementById('awalmenit').value;
                var akhirjam = document.getElementById('akhirjam').value;
                var akhirmenit = document.getElementById('akhirmenit').value;
                var runtimemenit = document.getElementById('runtimemenit').value;
                var runtimeshift = document.getElementById('runtimeshift').value;
                var runtimehari = document.getElementById('runtimehari').value;




                var result = parseFloat(akhir) - parseFloat(awal);
                var runtime = ((parseFloat(akhirjam) * 60) + parseFloat(akhirmenit)) - ((parseFloat(awaljam) * 60) + parseFloat(
                    awalmenit));
                var klkshift = (<?php echo e($item->jumlahpershift); ?> + parseFloat(kalkulasi));
                var klkhr = (<?php echo e($item->jumlahperhari); ?> + parseFloat(jumlahpershift));
                var rntmshift = (<?php echo e($item->runtimeshift); ?> + parseFloat(runtimemenit));
                var rntmehri = (<?php echo e($item->runtimehari); ?> + parseFloat(runtimeshift));


                <?php echo e($item->jumlahpershift); ?>


                if (!isNaN(result)) {
                    document.getElementById('kalkulasi').value = result;
                    document.getElementById('jumlahpershift').value = klkshift;
                    document.getElementById('runtimemenit').value = runtime;
                    document.getElementById('jumlahperhari').value = klkhr;
                    document.getElementById('runtimeshift').value = rntmshift;
                    document.getElementById('runtimehari').value = rntmehri;




                }
            }
        </script>

        <script type="text/javascript">
            $.fn.editable.defaults.mode = 'inline';

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            });

            $('.update').editable({
                url: "<?php echo e(route('superadmin.update.datacap', ['jalur_id' => $data->jalur_id, 'data' => $data->id])); ?>",
                type: 'text',
                pk: 1,
                name: 'name',
                title: 'Enter name',
                success:function(){ 
                document.location.reload(); 
                }
            });
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/superadmin/dashboard/logbook/indexcap.blade.php ENDPATH**/ ?>
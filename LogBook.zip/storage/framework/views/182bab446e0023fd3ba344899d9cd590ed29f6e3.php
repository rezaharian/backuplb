<!DOCTYPE html>
<html>

<head>
    <title>Daftar Hadir</title>

    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 12pt;
        }
    </style>
</head>

<body>


    <br>
    <strong style="font-family: Arial, Helvetica, sans-serif;">
        <center>Permasalahan Mesin</center>
    </strong>
    <br>



    <div>
        <div>
            <table border=""
                style="background: rgb(255, 255, 255); border:0;   font-family: Arial, Helvetica, sans-serif;">
                <tr>
                    <td style="width:20%; ">Kode </td>
                    <td> <strong> <?php echo e($view->prob_cod); ?> </strong></td>
                </tr>
                <tr>
                    <td>Line </td>

                    <td> <strong> <?php echo e($view->line); ?> </strong></td>
                </tr>
                <tr>
                    <td>Unit </td>

                    <td> <strong> <?php echo e($view->unitmesin); ?> </strong></td>
                </tr>
                <tr>
                    <td>Tgl Input </td>

                    <td> <strong> <?php echo e($view->tgl_input); ?> </strong></td>
                </tr>
                <tr>
                    <td>Masalah </td>

                    <td> <strong> <?php echo e($view->masalah); ?> </strong> </td>
                </tr>
                <br>
                <tr>
                    <td>Penyebab </td>

                    <td> <strong> <?php echo e($view_d->penyebab); ?> </strong></td>
                </tr>
                <tr>
                    <td>Tgl Perbaikan </td>

                    <td> <strong> <?php echo e($view_d->tgl_rpr); ?> </strong></td>
                </tr>
                <tr>
                    <td>Perbaikan </td>

                    <td> <strong> <?php echo e($view_d->perbaikan); ?> </strong></td>
                </tr>
                <tr>
                    <td>Tgl Pencegahan </td>

                    <td> <strong> <?php echo e($view_d->tgl_pre); ?> </strong></td>
                </tr>
                <tr>
                    <td> Pencegahan </td>

                    <td> <strong> <?php echo e($view_d->pencegahan); ?> </strong></td>
                </tr>
            </table>
            <h3>Gambar :</h3>
            <table>

                <tr>
                    <td>
                        

                    </td>
                </tr>
            </table>
        </div>

    </div>


</body>

</html>
<?php /**PATH C:\App\LogBook\resources\views/superadmin/dashboard/problemmsn/print.blade.php ENDPATH**/ ?>
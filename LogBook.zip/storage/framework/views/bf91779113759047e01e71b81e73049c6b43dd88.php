<?php $__env->startSection('content'); ?>
 dashboard nih

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/superadmin/dashboard/index.blade.php ENDPATH**/ ?>
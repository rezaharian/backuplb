<?php $__currentLoopData = $data_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/tr/cekpdf.blade.php ENDPATH**/ ?>
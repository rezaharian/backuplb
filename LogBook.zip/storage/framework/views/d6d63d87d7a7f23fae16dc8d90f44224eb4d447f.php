<!DOCTYPE html>
<html>

<head>
    <title>Mesin</title>

    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 12pt;
        }
    </style>
</head>

<body>


    <br>
    <strong style="font-family: Arial, Helvetica, sans-serif;">
        <center>Permasalahan Mesin</center>
    </strong>
    <br>



    <div>
        <div>
            <table border=""
                style="background: rgb(255, 255, 255); border:0;   font-family: Arial, Helvetica, sans-serif;">
                <tr>
                    <td style="width:20%; ">Kode </td>
                    <td> <strong> <?php echo e($view->prob_cod); ?> </strong></td>
                </tr>
                <tr>
                    <td>Line </td>

                    <td> <strong> <?php echo e($view->line); ?> </strong></td>
                </tr>
                <tr>
                    <td>Unit </td>

                    <td> <strong> <?php echo e($view->unitmesin); ?> </strong></td>
                </tr>
                <tr>
                    <td>Tgl Input </td>

                    <td> <strong> <?php echo e($view->tgl_input); ?> </strong></td>
                </tr>
                <tr>
                    <td>Masalah </td>

                    <td> <strong> <?php echo e($view->masalah); ?> </strong> </td>
                </tr>
                <br>
                
                <tr>
                    <td> <strong> Penyebab </strong></td>
                    <td> <strong> Tgl Perbaikan </strong></td>
                    <td> <strong> Perbaikan </strong></td>
                    <td> <strong> Tgl Pencegahan </strong></td>
                    <td> <strong>  Pencegahan </strong></td>

                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $view_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
              
                <tr>
                    <td> <?php echo e($item->penyebab); ?> </td>
                    <td> <?php echo e($item->tgl_rpr); ?> </td>
                    <td> <?php echo e($item->perbaikan); ?> </td>
                    <td> <?php echo e($item->tgl_pre); ?> </td>
                    <td> <?php echo e($item->pencegahan); ?> </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No Data</p>
                <?php endif; ?>
             
            </table>
            <h3>Gambar :</h3>
            <table>

                <tr>
                    <td>
                        

                    </td>
                </tr>
            </table>
        </div>

    </div>


</body>

</html>
<?php /**PATH C:\App\LogBook\resources\views/qc/dashboard/problemmsn/print_d.blade.php ENDPATH**/ ?>
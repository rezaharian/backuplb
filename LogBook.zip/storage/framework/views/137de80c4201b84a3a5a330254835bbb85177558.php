<?php $__env->startSection('contents'); ?>
    <div class="container">
        <h2>Selamat Datang Superadmin</h2>
        <form action="/logout" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Logout</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/superadmin/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<div class="container px-4">
    <a href="/hr/dashboard/training/tr/list/">
        <button type="button"  class="btn btn-outline-info">Training</button>
    </a>
    <div class="card bg-dark text-white border-0">

        <img class="card-img" src="https://hrrecruitment.extrupack.com/wp-content/uploads/2022/06/logo-extrupack-1-scaled.jpg" alt="Card image">
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('hr.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/index.blade.php ENDPATH**/ ?>
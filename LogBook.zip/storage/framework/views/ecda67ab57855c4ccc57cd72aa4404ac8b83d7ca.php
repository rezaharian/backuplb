<?php $__env->startSection('contents'); ?>
    <div class="container">
        <h2>Selamat Datang Bos</h2>
        <form action="/logout" method="post">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary" type="submit">Logout</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/bos/index.blade.php ENDPATH**/ ?>
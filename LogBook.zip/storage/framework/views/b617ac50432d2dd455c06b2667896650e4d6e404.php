

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-center">
                <p><?php echo e(Session::get('success')); ?></p>
            </div>
        <?php endif; ?>
            <div class="card">
                <div class="table-responsive">
                    <table class="table align-items-center mb-0">
                        <thead class="text-center">
                            <tr>
                                <th class=" font-weight-bolder opacity-7">Bagian</th>
                                <th class=" font-weight-bolder opacity-7 ps-2">Departement</th>
                                <th class=" font-weight-bolder opacity-7">Seksi</th>
                                <th class=" font-weight-bolder opacity-7">Opt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td class=" font-weight-bolder"><?php echo e($bag->bagian); ?></td>
                                    <td class=" font-weight-bolder"><?php echo e($bag->departemen); ?></td>
                                    <td class=" font-weight-bolder" class=" font-weight-bolder"><?php echo e($bag->seksi); ?></td>
                                    <td class="text-center">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('hr.bagian.delete', $bag->id)); ?>" method="POST">
                                            <a href="<?php echo e(route('hr.bagian.edit', $bag->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                        </form>
                                    </td>       
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <div class="col-md-4">
       
        <div class="card card-plain">
            <div class="card-header pb-0 text-left">
                <h4 class="font-weight-bolder text-info text-gradient">Tambah Bagian</h4>
            </div>
            <div class="card-body">
                <form role="form text-left" action="<?php echo e(url('/hr/dashboard/training/bagian/store')); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <label>Bagian</label>
                    <div class="input-group mb-3">
                        <input type="text"  name="bagian" class="form-control"
                            placeholder="bagian">
                    </div>
                    <label>Departemen</label>
                    <input  type="text"  name="departemen" class="form-control"
                            placeholder="departemen" >

                    <label>Seksi</label>
                    <input  type="text"  name="seksi" class="form-control"
                            placeholder="seksi" >
                      
                    <div class="text-center">
                        <button type="submit"
                            class="btn btn-round bg-gradient-info btn-lg w-100 mt-4 mb-0">Simpan</button>
                    </div>
                </form>
            </div>
        </div>


    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hr.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/bagian/index.blade.php ENDPATH**/ ?>
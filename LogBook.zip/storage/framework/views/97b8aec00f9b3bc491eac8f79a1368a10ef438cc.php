

<?php $__env->startSection('content'); ?>

<div class="container px-5">

    <div class="text-center font-xs">
        <strong>
            Data yang pernah di hapus :
        </strong>
    </div>
    <div>
        <?php $__currentLoopData = $data_dd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/hr/dashboard/training/tr/train_trash/restore_all/<?php echo e($item->train_cod); ?>" class="btn btn-success btn-sm">Restore All</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<table class="table">
    <thead class="bg-secondary text-light">
        <th>Kode</th>
        <th>Tanggal</th>
        <th>NIK</th>
        <th>Nama Karyawan</th>
        <th>Nilai</th>
        <th>Keterangan</th>
        <th>Cek HR</th>
        <th>Opsi</th>
    </thead>
    
    <?php $__empty_1 = true; $__currentLoopData = $data_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    
        
    <tr>
        <td><?php echo e($item->train_cod); ?></td>
        <td><?php echo e($item->train_dat); ?></td>
        <td><?php echo e($item->no_payroll); ?></td>
        <td><?php echo e($item->nama_asli); ?></td>
        <td><?php echo e($item->nilai); ?></td>
        <td><?php echo e($item->keterangan); ?></td>
        <td><?php echo e($item->approve); ?></td>  
        <td>
            <a href="/hr/dashboard/training/tr/train_trash/restore_trash/<?php echo e($item->id); ?>" class="btn btn-success btn-sm">Restore</a>

        </td> 
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
</table>
<h2>data tidak ada</h2>

    <?php endif; ?>
    
    
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('hr.dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\LogBook\resources\views/hr/dashboard/training/tr/train_trash.blade.php ENDPATH**/ ?>
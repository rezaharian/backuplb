<?php

namespace App\Http\Controllers;

use App\Models\bagian;
use App\Models\Coba;
use App\Models\kompe_d;
use App\Models\kompe_h;
use App\Models\pegawai;
use App\Models\prob_msd;
use App\Models\train_d;
use App\Models\train_h;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf as FacadePdf;
use Barryvdh\DomPDF\PDF as DomPDFPDF;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Testing\Constraints\SoftDeletedInDatabase;
use Illuminate\Database\Eloquent\SoftDeletes;
use Barryvdh\DomPDF\Facade\Pdf;

class trainingController extends Controller
{
    public function list()
    {
        $training = train_h::orderby('id', 'desc')->get();

        return view('hr.dashboard.training.tr.list', compact('training'));
    }
    public function view($id)
    {
        $view = train_h::findorfail($id);
        $view_d = train_d::where('train_cod', $view->train_cod)->get();

        // dd($view_d->toArray());
        return view('hr.dashboard.training.tr.view', compact('view', 'view_d'));
    }
    public function print($id)
    {
        $view = train_h::findorfail($id);
        $view_d = train_d::where('train_cod', $view->train_cod)->get();
        $tgl = carbon::now()->format('d-m-Y');
        // $bag = pegawai::where('no_payroll', $view_d->no_payroll)->get();
        // dd($view_d->toArray());
        // dd($view->toArray());

        $pdf = Pdf::loadview('hr.dashboard.training.tr.print', compact('view', 'view_d', 'tgl'));
        return $pdf->setPaper('a4', 'potrait')->stream('DaftarHadir.pdf');
    }

    public function create(Request $request)
    {
        $kompe_d = kompe_d::orderBy('kompetensi', 'asc')->get();
        $train_h = train_h::select('id', 'train_cod')
            ->orderby('id', 'desc')
            ->first();
        $pegawai = pegawai::select('nama', 'nama_asli', 'no_payroll')->get();
        $data = pegawai::select('nama', 'nama_asli', 'no_payroll')->get();

        // pecah no akhir
        $noakhir = $train_h->train_cod;
        $tra_p = substr($noakhir, 0, 3);
        $thna_p = substr($noakhir, 3, 2);
        $bln_p = substr($noakhir, 6, 2);
        $urut_p = substr($noakhir, 8, 3);
        // tahun
        $thn = Carbon::now()->format('Y');
        $bln = Carbon::now()->format('m');
        $thn_p = substr($thn, 2, 2);
        $urut_p++;

        if ($thna_p != $thn_p) {
            $nmr_d = 001;
        } else {
            $nmr_d = $urut_p;
        }

        // dd($nmr_d);
        // dd($tra_p . $thn_p . $bln . $nmr_d);
        $no = $tra_p . $thn_p . $bln . sprintf('%03s', $nmr_d);
        return view('hr.dashboard.training.tr.create', compact('kompe_d', 'no', 'pegawai', 'data'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'train_cod' => 'required|unique:train_hs,train_cod',
        ]);

        $kompe_h = train_h::create([
            'train_cod' => $request->train_cod,
            'pemateri' => $request->pemateri,
            'tempat' => $request->tempat,
            'pemateri' => $request->pemateri,
            'pemateri' => $request->pemateri,
            'pltran_nam' => $request->pltran_nam,
            'kompetensi' => $request->kompetensi,
            'train_dat' => $request->train_dat,
            'jam' => $request->jam,
            'sdjam' => $request->sdjam,
            'train_tema' => $request->train_tema,
            'approve' => $request->approve_h,
            'tipe' => $request->tipe,
        ]);

        foreach ($request->no_payroll as $key => $value) {
            train_d::create([
                'no_payroll' => $value,
                'nama_asli' => $request->nama_asli[$key],
                'nilai' => $request->nilai[$key],
                'keterangan' => $request->keterangan[$key],
                'approve' => $request->approve[$key],
                'train_cod' => $request->train_cod,
                'train_dat' => $request->train_dat,
            ]);
        }

        return redirect()
            ->route('hr.training.list')
            ->with('success', 'New subject has been added.');
    }

    public function edit(Request $request, $id)
    {
        $data = train_h::findorfail($id);
        $data_d = train_d::where('train_cod', $data->train_cod)
            ->orderby('id', 'asc')
            ->get();
        $jmlh_d = count($data_d);

        // dd($view_d->toArray());
        return view('hr.dashboard.training.tr.edit', compact('data', 'data_d', 'jmlh_d'));
    }

    public function update($id, Request $request, train_d $train_d, train_h $train_h)
    {
        $data_h = train_h::where('id', $id)->first();
        $data_d = train_d::all();

        $data_h->train_cod = $request->train_cod;
        $data_h->tempat = $request->tempat;
        $data_h->pemateri = $request->pemateri;
        $data_h->pltran_nam = $request->pltran_nam;
        $data_h->tipe = $request->tipe;
        $data_h->kompetensi = $request->kompetensi;
        $data_h->train_dat = $request->train_dat;
        $data_h->jam = $request->jam;
        $data_h->sdjam = $request->sdjam;
        $data_h->train_tema = $request->train_tema;
        $data_h->approve = $request->approve;
        $data_h->save();

        foreach ($request->no_payroll as $key => $value) {
            if (isset($request->item_id[$key])) {
                train_d::where('id', $request->item_id[$key])->update([
                    'no_payroll' => $value,
                    'nama_asli' => $request->nama_asli[$key],
                    'nilai' => $request->nilai[$key],
                    'keterangan' => $request->keterangan[$key],
                    'approve' => $request->approved[$key],
                    'train_cod' => $request->train_cod,
                    'train_dat' => $request->train_dat,
                ]);
            } else {
                train_d::create([
                    'no_payroll' => $value,
                    'nama_asli' => $request->nama_asli[$key],
                    'nilai' => $request->nilai[$key],
                    'keterangan' => $request->keterangan[$key],
                    'approve' => $request->approved[$key],
                    'train_cod' => $request->train_cod,
                    'train_dat' => $request->train_dat,
                ]);
            }
        }
        return redirect()
            ->route('hr.training.list')
            ->with('success', 'New subject has been added.');
    }

    public function train_trash($id, train_d $data_d)
    {
        $data = train_h::findorfail($id);
        $data_d = train_d::onlyTrashed()
            ->where('train_cod', $data->train_cod)
            ->orderby('id', 'asc')
            ->get();
        $data_dd = train_d::onlyTrashed()
            ->where('train_cod', $data->train_cod)
            ->orderby('id', 'asc')
            ->limit(1)
            ->get();

        // dd($data_d->toArray());
        return view('hr.dashboard.training.tr.train_trash', compact('data_d', 'data_dd'));
    }

    public function delete($id, train_h $train_d)
    {
        $trainh = train_h::findOrFail($id);
        $traind = train_d::where('train_cod', $trainh->train_cod);
        $trainh->delete();
        $traind->delete();
        return redirect()
            ->route('hr.training.list')
            ->with('success', 'Data berhasil dihapus!');
    }

    public function delete_d($id, train_d $train_d)
    {
        $train = train_d::findOrFail($id);
        $train->delete();
        return back();
    }

    public function restore_trash($id, train_d $data_d)
    {
        $data_d = train_d::onlyTrashed()->where('id', $id);
        // dd($data_d->toArray());
        $data_d->restore();
        return back()->with('success', 'Data berhasil dipulihkan!');
    }

    public function restore_all($id, train_d $data_d)
    {
        $data_d_all = train_d::onlyTrashed()->where('train_cod', $id);
        $data_d_all->restore();
        return back()->with('success', 'Data berhasil dipulihkan!');
    }

    public function autocomplete(Request $request)
    {
        dd($request->toArray());

    	$us = [];
        if($request->has('q')){
            $search = $request->q;
            $us =user::select("id", "name")
            		->where('name', 'LIKE', "%$search%")
            		->get();
        }
        return response()->json($us);
    }

    public function cb(Request $request)
    {    

        $kompe_d = kompe_d::orderBy('kompetensi', 'asc')->get();
        $train_h = train_h::select('id', 'train_cod')
            ->orderby('id', 'desc')
            ->first();
        $data = prob_msd::select('id', 'penyebab', 'perbaikan','pencegahan')
        ->get();
        $data1 = prob_msd::select('perbaikan')->where('id', );
        $us = User::select('name', 'email')->get();
        // dd($us);

        return view('hr.dashboard.training.tr.cb', compact('data','kompe_d','train_h','data1','us'));
    }


}

<?php

namespace App\Http\Controllers;

use App\Models\train_d;
use App\Models\train_h;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TrainerController extends Controller
{
    public function index()
    {
        $namaprofile = Auth::user();

        return view('hr.dashboard.training.trainer.index', compact('namaprofile'));
    }

    public function list()
    {
        $training = train_h::orderby('id', 'desc')->get();
        $namaprofile = Auth::user();
        return view('hr.dashboard.training.trainer.list', compact('training', 'namaprofile'));
    }

    public function view($id)
    {
        $view = train_h::findorfail($id);
        $view_d = train_d::where('train_cod', $view->train_cod)->get();
        $namaprofile = Auth::user();
        return view('hr.dashboard.training.trainer.view', compact('view', 'view_d', 'namaprofile'));
    }

    public function edit($id)
    {
        $data = train_h::findorfail($id);
        $data_d = train_d::where('train_cod', $data->train_cod)
            ->orderby('id', 'asc')
            ->get();
        $jmlh_d = count($data_d);
        $namaprofile = Auth::user();
        return view('hr.dashboard.training.trainer.edit', compact('data', 'data_d', 'jmlh_d', 'namaprofile'));
    }

    public function update($id, Request $request, train_d $train_d, train_h $train_h)
    {
        $data_h = train_h::where('id', $id)->first();
        $data_d = train_d::all();

        $data_h->train_cod = $request->train_cod;
        $data_h->tempat = $request->tempat;
        $data_h->pemateri = $request->pemateri;
        $data_h->pltran_nam = $request->pltran_nam;
        $data_h->tipe = $request->tipe;
        $data_h->kompetensi = $request->kompetensi;
        $data_h->train_dat = $request->train_dat;
        $data_h->jam = $request->jam;
        $data_h->sdjam = $request->sdjam;
        $data_h->train_tema = $request->train_tema;
        $data_h->approve = $request->approve;
        $data_h->save();

        foreach ($request->no_payroll as $key => $value) {
            if (isset($request->item_id[$key])) {
                train_d::where('id', $request->item_id[$key])->update([
                    'no_payroll' => $value,
                    'nama_asli' => $request->nama_asli[$key],
                    'nilai' => $request->nilai[$key],
                    'keterangan' => $request->keterangan[$key],
                    'approve' => $request->approved[$key],
                    'train_cod' => $request->train_cod,
                    'train_dat' => $request->train_dat,
                ]);
            } else {
                train_d::create([
                    'no_payroll' => $value,
                    'nama_asli' => $request->nama_asli[$key],
                    'nilai' => $request->nilai[$key],
                    'keterangan' => $request->keterangan[$key],
                    'approve' => $request->approved[$key],
                    'train_cod' => $request->train_cod,
                    'train_dat' => $request->train_dat,
                ]);
            }
        }
        return redirect()
            ->route('trainer.list')
            ->with('success', 'New subject has been added.');
    }
}

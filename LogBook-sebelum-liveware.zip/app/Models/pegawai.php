<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pegawai extends Model
{

    protected $fillable = [
        'nama_asli',
        'no_reg',
  
    ];
    // protected $fillable = [
    //     'id',
    //     'noreg_awal',
    //     'no_reg',
    //     'tgl_noreg',  
    //     'no_peg',  
    //     'no_payroll',  
    //     'nama',  
    //     'nama_asli',  
    //     'tgl_lahir',  
    //     'sex',  
    //     'agama',  
    //     'alamat',  
    //     'kota',  
    //     'departemen',  
    //     'bagian',  
    //     'jabatan',  
    //     'golongan',  
    // ];
}

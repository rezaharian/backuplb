<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SuperadminController;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\RedirectController;
use App\Http\Controllers\BosController;
use App\Http\Controllers\DashboardSuperAdminController;
use App\Http\Controllers\DashboardSuperAdminCapController;
use App\Http\Controllers\DataMasterController;
use App\Http\Controllers\HrController;
use App\Http\Controllers\HrTrainingController;
use App\Http\Controllers\JalurController;
use App\Http\Controllers\kompetensiController;
use App\Http\Controllers\OpController;
use App\Http\Controllers\ProblemMesinController;
use App\Http\Controllers\QcController;
use App\Http\Controllers\TrainerController;
use App\Http\Controllers\trainingController;
use App\Models\pegawai;
use App\Models\train_d;
use GuzzleHttp\Psr7\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//  jika user belum login
Route::group(['middleware' => 'guest'], function () {
    Route::get('/', [AuthController::class, 'login'])->name('login');
    Route::post('/', [AuthController::class, 'dologin']);
});

// untuk superadmin, bos dan pegawai
Route::group(['middleware' => ['auth', 'checkrole:1,2,3,4,5,6,7,8']], function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/redirect', [RedirectController::class, 'cek']);

    //menambahkan field master shift
    route::post('/store-input-fields-master', [DataMasterController::class, 'store']);
});

// untuk superadmin
Route::group(['middleware' => ['auth', 'checkrole:1']], function () {
    Route::get('/superadmin', [SuperadminController::class, 'index']);
    Route::get('/superadmin/dashboard', [DashboardSuperAdminController::class, 'index']);

    //user
    route::get('/superadmin/dashboard/user', [DashboardSuperAdminController::class, 'indexUser'])->name('superadmin.user.index');
    route::post('/superadmin/dashboard/user/store', [DashboardSuperAdminController::class, 'storeUser']);
    route::delete('/superadmin/dashboard/user/destroy/{id}', [DashboardSuperAdminController::class, 'destroyUser'])->name('superadmin.destroy.user');
    route::get('/superadmin/dashboard/user/edit/{id}', [DashboardSuperAdminController::class, 'editUser'])->name('superadmin.edit.user');
    route::post('/superadmin/dashboard/user/update/{id}', [DashboardSuperAdminController::class, 'updateUser'])->name('superadmin.update.user');
  
    //profile
    route::get('/superadmin/dashboard/profile', [DashboardSuperAdminController::class, 'profileAdmin'])->name('superadmin.dashboard.profile');

    //LogBook
    route::get('/superadmin/dashboard/loogbok/{jalur_id}/data', [DashboardSuperAdminController::class, 'indexData'])->name('superadmin.index.data');
    route::get('/superadmin/dashboard/logbook/{jalur_id}/pencarian', [DashboardSuperAdminController::class, 'indexCariData'])->name('superadmin.index.cari.data');
    route::post('/superadmin/dashboard/loogbok/{jalur_id}/update/{data}', [DashboardSuperAdminController::class, 'update'])->name('superadmin.update.data');
    route::get('/superadmin/dashboard/loogbok/{jalur_id}/reset/{data}', [DashboardSuperAdminController::class, 'reset'])->name('superadmin.reset.data');
    route::get('/superadmin/dashboard/loogbok/{jalur_id}/batalresetpcs/{data}', [DashboardSuperAdminController::class, 'batalresetpcs'])->name('superadmin.batalresetpcs.data');
    route::get('/superadmin/dashboard/loogbok/{jalur_id}/batalresetpcsfresh/{data}', [DashboardSuperAdminController::class, 'batalresetpcsrefresh'])->name('superadmin.batalresetpcsrefresh.data');
    route::get('/superadmin/dashboard/loogbok/{jalur_id}/resetwaktu/{data}', [DashboardSuperAdminController::class, 'resetwaktu'])->name('superadmin.resetwaktu.data');
    route::get('/superadmin/dashboard/loogbok/{jalur_id}/batalresettime/{data}', [DashboardSuperAdminController::class, 'batalresettime'])->name('superadmin.batalresettime.data');
    route::post('/superadmin/dashboard/loogbok/insertfielddata/{jalur_id}',[DashboardSuperAdminController::class, 'insertfielddata'])->name('superadmin.insertfielddata.data');
    route::get('/superadmin/dashboard/loogbok/delete/{jalur_id}', [DashboardSuperAdminController::class, 'deleteTmpData'])->name('superadmin.delete.data');

    //LogBook Capp
    route::get('/superadmin/dashboard/loogbokcap/{jalur_id}/data', [DashboardSuperAdminCapController::class, 'indexData'])->name('superadmin.index.datacap');
    route::get('/superadmin/dashboard/logbookcap/{jalur_id}/pencarian', [DashboardSuperAdminCapController::class, 'indexCariData'])->name('superadmin.index.cari.datacap');
    route::post('/superadmin/dashboard/loogbokcap/{jalur_id}/update/{data}', [DashboardSuperAdminCapController::class, 'update'])->name('superadmin.update.datacap');
    route::get('/superadmin/dashboard/loogbokcap/{jalur_id}/reset/{data}', [DashboardSuperAdminCapController::class, 'reset'])->name('superadmin.reset.datacap');
    route::get('/superadmin/dashboard/loogbokcap/{jalur_id}/batalresetpcs/{data}', [DashboardSuperAdminCapController::class, 'batalresetpcs'])->name('superadmin.batalresetpcs.datacap');
    route::get('/superadmin/dashboard/loogbokcap/{jalur_id}/batalresetpcsfresh/{data}', [DashboardSuperAdminCapController::class, 'batalresetpcsrefresh'])->name('superadmin.batalresetpcsrefresh.datacap');
    route::get('/superadmin/dashboard/loogbokcap/{jalur_id}/resetwaktu/{data}', [DashboardSuperAdminCapController::class, 'resetwaktu'])->name('superadmin.resetwaktu.datacap');
    route::get('/superadmin/dashboard/loogbokcap/{jalur_id}/batalresettime/{data}', [DashboardSuperAdminCapController::class, 'batalresettime'])->name('superadmin.batalresettime.datacap');
    route::post('/superadmin/dashboard/loogbokcap/insertfielddata/{jalur_id}',[DashboardSuperAdminCapController::class, 'insertfielddata'])->name('superadmin.insertfielddata.datacap');
    route::get('/superadmin/dashboard/loogbokcap/delete/{jalur_id}', [DashboardSuperAdminCapController::class, 'deleteTmpData'])->name('superadmin.delete.datacap');


    //jalur
    route::get('/superadmin/dashboard/loogbok/line',[DashboardSuperAdminController::class, 'lineloogbok'])->name('superadmin.line.data');
    route::post('/superadmin/dashboard/jalur/store',[DashboardSuperAdminController::class, 'storeJalur'])->name('superadmin.line.store');
    //jalur Capping   
    route::get('/superadmin/dashboard/loogbok/linecap',[DashboardSuperAdminCapController::class, 'lineloogbokcap'])->name('superadmin.linecap.data');
    route::post('/superadmin/dashboard/jalurcap/store',[DashboardSuperAdminCapController::class, 'storeJalurcap'])->name('superadmin.linecap.store');

    // Problem Mesin
    Route::get('/superadmin/dashboard/problemmsn', [ProblemMesinController::class, 'index'])->name('adm.problemmsn.index');
    Route::get('/superadmin/dashboard/problemmsn/list', [ProblemMesinController::class, 'list'])->name('adm.problemmsn.list');
    Route::get('/superadmin/dashboard/problemmsn/view/{id}', [ProblemMesinController::class, 'view'])->name('adm.problemmsn.view');
    Route::get('/superadmin/dashboard/problemmsn/view_d/{id}', [ProblemMesinController::class, 'view_d'])->name('adm.problemmsn.view_d');
    Route::get('/superadmin/dashboard/problemmsn/create', [ProblemMesinController::class, 'create'])->name('adm.problemmsn.create');
    Route::post('/superadmin/dashboard/problemmsn/store', [ProblemMesinController::class, 'store'])->name('adm.problemmsn.store');
    Route::get('/superadmin/dashboard/problemmsn/edit/{id}', [ProblemMesinController::class, 'edit'])->name('adm.problemmsn.edit');
    Route::post('/superadmin/dashboard/problemmsn/update/{id}', [ProblemMesinController::class, 'update'])->name('adm.problemmsn.update');
    Route::get('/superadmin/dashboard/problemmsn/delete/{id}', [ProblemMesinController::class, 'delete'])->name('adm.problemmsn.delete');
    Route::delete('/superadmin/dashboard/problemmsn/delete_d/{id}', [ProblemMesinController::class, 'delete_d'])->name('adm.problemmsn.delete_d');
    Route::get('/superadmin/dashboard/problemmsn/print/{id}', [ProblemMesinController::class, 'print'])->name('adm.problemmsn.print');
    Route::get('/superadmin/dashboard/problemmsn/print_d/{id}', [ProblemMesinController::class, 'print_d'])->name('adm.problemmsn.print_d');

});


// untuk bos
Route::group(['middleware' => ['auth', 'checkrole:2']], function () {
    Route::get('/bos', [BosController::class, 'index']);
});

// untuk pegawai
Route::group(['middleware' => ['auth', 'checkrole:4']], function () {
    Route::get('/pegawai', [PegawaiController::class, 'index']);
});

//HR
Route::group(['middleware' => ['auth', 'checkrole:3']], function () {
    // bagian
    Route::get('/hr', [HrController::class, 'index']);
    Route::get('/hr/dashboard/training/bagian/index', [HrTrainingController::class, 'bagianIndex'])->name('hr.bagian.index');
    Route::post('/hr/dashboard/training/bagian/store', [HrTrainingController::class, 'storebag'])->name('hr.bagian.store');
    Route::delete('/hr/dashboard/training/bagian/delete{id}', [HrTrainingController::class, 'delete'])->name('hr.bagian.delete');
    Route::get('/hr/dashboard/training/bagian/edit/{id}', [HrTrainingController::class, 'edit'])->name('hr.bagian.edit');
    Route::post('/hr/dashboard/training/bagian/update/{id}', [HrTrainingController::class, 'update'])->name('hr.bagian.update');
    // Kompetensi
    Route::get('/hr/dashboard/training/kompetensi/list', [kompetensiController::class, 'list'])->name('hr.kompetensi.list');
    Route::get('/hr/dashboard/training/kompetensi/view/{id}', [kompetensiController::class, 'view'])->name('hr.kompetensi.view');
    Route::get('/hr/dashboard/training/kompetensi/delete/{id}', [kompetensiController::class, 'delete'])->name('hr.kompetensi.delete');
    Route::post('/hr/dashboard/training/kompetensi/update/{id}', [kompetensiController::class, 'update'])->name('hr.kompetensi.update');
    Route::get('/hr/dashboard/training/kompetensi/edit/{id}', [kompetensiController::class, 'edit'])->name('hr.kompetensi.edit');
    Route::get('/hr/dashboard/training/kompetensi/create', [kompetensiController::class, 'create'])->name('hr.kompetensi.create');
    Route::post('/hr/dashboard/training/kompetensi/store', [kompetensiController::class, 'store'])->name('hr.kompetensi.store');
    Route::post('/hr/dashboard/training/kompetensi/delete_d/{id}', [kompetensiController::class, 'delete_d'])->name('hr.kompetensi.delete_d');
    // training
    Route::get('/hr/dashboard/training/tr/list', [trainingController::class, 'list'])->name('hr.training.list');
    Route::get('/hr/dashboard/training/tr/view/{id}', [trainingController::class, 'view'])->name('hr.training.view');
    Route::get('/hr/dashboard/training/tr/delete/{id}', [trainingController::class, 'delete'])->name('hr.training.delete');
    Route::get('/autocomplete', [trainingController::class, 'autocomplete'])->name('hr.training.autocomplete');
    Route::get('/hr/dashboard/training/tr/create', [trainingController::class, 'create'])->name('hr.training.create');
    Route::get('/hr/dashboard/training/tr/cb', [trainingController::class, 'cb'])->name('hr.training.cb');
    Route::post('/hr/dashboard/training/tr/store', [trainingController::class, 'store'])->name('hr.training.store');
    Route::get('/hr/dashboard/training/tr/edit/{id}', [trainingController::class, 'edit'])->name('hr.training.edit');
    Route::post('/hr/dashboard/training/tr/update/{id}', [trainingController::class, 'update'])->name('hr.training.update');
    Route::get('/hr/dashboard/training/tr/print/{id}', [trainingController::class, 'print'])->name('hr.training.print');
    Route::delete('/hr/dashboard/training/tr/delete_d/{id}', [trainingController::class, 'delete_d'])->name('hr.training.delete_d');
    Route::get('/hr/dashboard/training/tr/train_trash/{id}', [trainingController::class, 'train_trash'])->name('hr.training.train_trash');
    Route::get('/hr/dashboard/training/tr/train_trash/restore_trash/{id}', [trainingController::class, 'restore_trash'])->name('hr.training.train_trash.restore_trash');
    Route::get('/hr/dashboard/training/tr/train_trash/restore_all/{id}', [trainingController::class, 'restore_all'])->name('hr.training.train_trash.restore_all');
    
});

// trainer 
Route::group(['middleware' => ['auth', 'checkrole:5']], function () {
    Route::get('/trainer', [TrainerController::class, 'index'])->name('index');
    Route::get('/trainer/list', [TrainerController::class, 'list'])->name('trainer.list');
    Route::get('/trainer/view/{id}', [TrainerController::class, 'view'])->name('trainer.view');
    Route::get('/trainer/edit/{id}', [TrainerController::class, 'edit'])->name('trainer.edit');
    Route::post('/trainer/update/{id}', [trainingController::class, 'update'])->name('hr.training.update');

});

// untuk QC
Route::group(['middleware' => ['auth', 'checkrole:6']], function () {
    Route::get('/qc', [QcController::class, 'index'])->name('problemmsn.index');
    Route::get('/qc/dashboard/problemmsn/list', [QcController::class, 'list'])->name('problemmsn.list');
    Route::get('/qc/dashboard/problemmsn/view/{id}', [QcController::class, 'view'])->name('problemmsn.view');
    Route::get('/qc/dashboard/problemmsn/view_d/{id}', [QcController::class, 'view_d'])->name('problemmsn.view_d');
    Route::get('/qc/dashboard/problemmsn/create', [QcController::class, 'create'])->name('problemmsn.create');
    Route::post('/qc/dashboard/problemmsn/store', [QcController::class, 'store'])->name('problemmsn.store');
    Route::get('/qc/dashboard/problemmsn/edit/{id}', [QcController::class, 'edit'])->name('problemmsn.edit');
    Route::post('/qc/dashboard/problemmsn/update/{id}', [QcController::class, 'update'])->name('problemmsn.update');
    Route::get('/qc/dashboard/problemmsn/delete/{id}', [QcController::class, 'delete'])->name('problemmsn.delete');
    Route::delete('/qc/dashboard/problemmsn/delete_d/{id}', [QcController::class, 'delete_d'])->name('problemmsn.delete_d');
    Route::get('/qc/dashboard/problemmsn/print/{id}', [QcController::class, 'print'])->name('problemmsn.print');
    Route::get('/qc/dashboard/problemmsn/print_d/{id}', [QcController::class, 'print_d'])->name('problemmsn.print_d');

});
// Op
Route::group(['middleware' => ['auth', 'checkrole:7']], function () {
    Route::get('/produksi', [OpController::class, 'produksi'])->name('op.problemmsn.produksi');
    Route::get('/op', [OpController::class, 'index'])->name('op.problemmsn.index');
    Route::get('/op/dashboard/problemmsn/list', [OpController::class, 'list'])->name('op.problemmsn.list');
    Route::get('/op/dashboard/problemmsn/view_d/{id}', [OpController::class, 'view_d'])->name('op.problemmsn.view_d');
    Route::get('/op/dashboard/problemmsn/create', [OpController::class, 'create'])->name('op.problemmsn.create');
    Route::get('/op/dashboard/problemmsn/print/{id}', [OpController::class, 'print'])->name('op.problemmsn.print');
    Route::get('/op/dashboard/problemmsn/print_d/{id}', [OpController::class, 'print_d'])->name('op.problemmsn.print_d');

});
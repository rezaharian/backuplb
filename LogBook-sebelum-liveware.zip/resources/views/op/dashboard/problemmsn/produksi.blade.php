@extends('op.dashboard.layout.layout')

@section('content')


<h3>Halaaman Operator Produksi</h3>

@endsection

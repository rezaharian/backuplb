@extends('hr.dashboard.layout.layout')

@section('content')

<div class="container px-4">
    <a href="/hr/dashboard/training/tr/list/">
        <button type="button"  class="btn btn-outline-info">Training</button>
    </a>
    <div class="card bg-dark text-white border-0">

        <img class="card-img" src="https://hrrecruitment.extrupack.com/wp-content/uploads/2022/06/logo-extrupack-1-scaled.jpg" alt="Card image">
    </div>

</div>

@endsection
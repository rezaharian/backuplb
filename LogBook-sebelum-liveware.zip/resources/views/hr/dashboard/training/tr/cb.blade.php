{{-- 
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<select name="name" id="selectname">
  <option value="User 1">User 1</option>
  <option value="User 2">User 2</option>
  <option value="User 3">User 3</option>
  <option value="User 4">User 4</option>
  <option value="User 5">User 5</option>
</select>

<input type="text" class="form-control" placeholder="username" name="username" id="username" value="" disabled required />

<input type="text" class="form-control" placeholder="username" name="username2" id="username2" value="" disabled required />
</div>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
document.getElementById("selectname").onchange = function() {
  var e = document.getElementById("selectname");
  var strUser = e.options[e.selectedIndex].value;
  document.getElementById("username").value = strUser;
};

// jQuery

$('body').on('change', '#selectname', function() {
$('#username2').val($('#selectname option:selected').val());
});
</script>
</body>
</html> --}}

<div>Departments </div>
       
<select id="sel_depart">
   <option value="0">- Select -</option>
  
</select>
<div class="clear"></div>

<div>Users </div>
<select id="sel_user">
   <option value="0">- Select -</option>
</select>